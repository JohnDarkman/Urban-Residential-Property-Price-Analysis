
# Install and load necessary libraries
if (!requireNamespace("tidyverse", quietly = TRUE)) {
  install.packages("tidyverse")
}
library(tidyverse)

# Import default cleaned data
KLpropdata <- read.csv("C:\\Users\\Windows\\Downloads\\PFDA\\cleaned_data_default.csv", header = TRUE)

# View table
View(KLpropdata)

# Data Analysis
# Analysis 1: Property Type Segmentation In Kuala Lumpur

# Define property types
property_types <- c(
  "Bungalow (Corner)", "Bungalow", "Condominium (Corner)", "Bungalow (Intermediate)", 
  "Condominium", "Semi-detached House", "2-sty Terrace/Link House (EndLot)",
  "2-sty Terrace/Link House (Intermediate)", "2-sty Terrace/Link House", 
  "3.5-sty Terrace/Link House (Intermediate)", "2-sty Terrace/Link House (Corner)", 
  "Semi-detached House (Intermediate)", "4-sty Terrace/Link House (Corner)", 
  "Condominium (Intermediate)", "3-sty Terrace/Link House (Intermediate)", 
  "Townhouse (EndLot)", "Semi-detached House (Triplex)", "Condominium (Duplex)", 
  "Bungalow (EndLot)", "Serviced Residence", "2.5-sty Terrace/Link House (EndLot)",
  "Townhouse", "Condominium (EndLot)", "3.5-sty Terrace/Link House", 
  "Residential Land", "Condominium (Triplex)", "4-sty Terrace/Link House", 
  "Condominium (Penthouse)", "3-sty Terrace/Link House (EndLot)", 
  "1.5-sty Terrace/Link House (Corner)"
)

# Initialize an empty data frame to store counts
property_counts <- data.frame(Property_Type = character(0), Count = numeric(0))

# Loop through each property type and calculate counts
for (prop_type in property_types) {
  prop_data <- KLpropdata[KLpropdata$Property.Type == prop_type, ]
  count <- nrow(prop_data)
  cat(prop_type, "Data:\n")
  print(prop_data)
  cat("Number of Rows for", prop_type, ":", count, "\n\n")
  # Append counts to the data frame
  property_counts <- rbind(property_counts, data.frame(Property_Type = prop_type, Count = count))
}

# Graph for Analysis 1
# Create an advanced bar plot
ggplot(property_counts, aes(x = reorder(Property_Type, Count), y = Count)) +
  geom_bar(stat = "identity", fill = "#3498db", width = 0.7, color = "black") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1),
        plot.title = element_text(hjust = 0.5)) +
  ggtitle("Property Type Segmentation in Kuala Lumpur") +
  xlab("Property Type") +
  ylab("Count") +
  geom_text(aes(label = Count), vjust = -0.5, size = 3, color = "black") +
  coord_flip() +
  scale_y_continuous(labels = scales::comma) +
  scale_fill_manual(values = c("#3498db"))


#Analysis 2: Property Type Segmentation In Bangsar

#import clean data
KLpropdata_Bangsar <- read.csv("C:\\Users\\Windows\\Downloads\\cleaned_dataset_final.csv", header = TRUE)

# Bungalow (Corner) in Bangsar
Bungalow_Corner_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "Bungalow (Corner)", ]
print("Bungalow (Corner) Data in Bangsar:")
print(Bungalow_Corner_Bangsar)
cat("Number of Rows for Bungalow (Corner) in Bangsar:", nrow(Bungalow_Corner_Bangsar), "\n\n")

# Bungalow in Bangsar
Bungalow_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "Bungalow", ]
print("Bungalow Data in Bangsar:")
print(Bungalow_Bangsar)
cat("Number of Rows for Bungalow in Bangsar:", nrow(Bungalow_Bangsar), "\n\n")

# Condominium (Corner) in Bangsar
Condominium_Corner_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "Condominium (Corner)", ]
print("Condominium (Corner) Data in Bangsar:")
print(Condominium_Corner_Bangsar)
cat("Number of Rows for Condominium (Corner) in Bangsar:", nrow(Condominium_Corner_Bangsar), "\n\n")

# Bungalow (Intermediate) in Bangsar
Bungalow_Intermediate_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "Bungalow (Intermediate)", ]
print("Bungalow (Intermediate) Data in Bangsar:")
print(Bungalow_Intermediate_Bangsar)
cat("Number of Rows for Bungalow (Intermediate) in Bangsar:", nrow(Bungalow_Intermediate_Bangsar), "\n\n")

# Condominium in Bangsar
Condominium_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "Condominium", ]
print("Condominium Data in Bangsar:")
print(Condominium_Bangsar)
cat("Number of Rows for Condominium in Bangsar:", nrow(Condominium_Bangsar), "\n\n")

# Semi-detached House in Bangsar
Semi_Detached_House_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "Semi-detached House", ]
print("Semi-detached House Data in Bangsar:")
print(Semi_Detached_House_Bangsar)
cat("Number of Rows for Semi-detached House in Bangsar:", nrow(Semi_Detached_House_Bangsar), "\n\n")

# 2-sty Terrace/Link House (EndLot) in Bangsar
TwoStory_Terrace_LinkHouse_EndLot_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "2-sty Terrace/Link House (EndLot)", ]
print("2-sty Terrace/Link House (EndLot) Data in Bangsar:")
print(TwoStory_Terrace_LinkHouse_EndLot_Bangsar)
cat("Number of Rows for 2-sty Terrace/Link House (EndLot) in Bangsar:", nrow(TwoStory_Terrace_LinkHouse_EndLot_Bangsar), "\n\n")

# 2-sty Terrace/Link House (Intermediate) in Bangsar
TwoStory_Terrace_LinkHouse_Intermediate_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "2-sty Terrace/Link House (Intermediate)", ]
print("2-sty Terrace/Link House (Intermediate) Data in Bangsar:")
print(TwoStory_Terrace_LinkHouse_Intermediate_Bangsar)
cat("Number of Rows for 2-sty Terrace/Link House (Intermediate) in Bangsar:", nrow(TwoStory_Terrace_LinkHouse_Intermediate_Bangsar), "\n\n")

# 2-sty Terrace/Link House in Bangsar
TwoStory_Terrace_LinkHouse_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "2-sty Terrace/Link House", ]
print("2-sty Terrace/Link House Data in Bangsar:")
print(TwoStory_Terrace_LinkHouse_Bangsar)
cat("Number of Rows for 2-sty Terrace/Link House in Bangsar:", nrow(TwoStory_Terrace_LinkHouse_Bangsar), "\n\n")

# 3.5-sty Terrace/Link House (Intermediate) in Bangsar
ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "3.5-sty Terrace/Link House (Intermediate)", ]
print("3.5-sty Terrace/Link House (Intermediate) Data in Bangsar:")
print(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar)
cat("Number of Rows for 3.5-sty Terrace/Link House (Intermediate) in Bangsar:", nrow(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar), "\n\n")

# 2-sty Terrace/Link House (Corner) in Bangsar
TwoStory_Terrace_LinkHouse_Corner_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "2-sty Terrace/Link House (Corner)", ]
print("2-sty Terrace/Link House (Corner) Data in Bangsar:")
print(TwoStory_Terrace_LinkHouse_Corner_Bangsar)
cat("Number of Rows for 2-sty Terrace/Link House (Corner) in Bangsar:", nrow(TwoStory_Terrace_LinkHouse_Corner_Bangsar), "\n\n")

# Semi-detached House (Intermediate) in Bangsar
Semi_Detached_House_Intermediate_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "Semi-detached House (Intermediate)", ]
print("Semi-detached House (Intermediate) Data in Bangsar:")
print(Semi_Detached_House_Intermediate_Bangsar)
cat("Number of Rows for Semi-detached House (Intermediate) in Bangsar:", nrow(Semi_Detached_House_Intermediate_Bangsar), "\n\n")

# 4-sty Terrace/Link House (Corner) in Bangsar
FourStory_Terrace_LinkHouse_Corner_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "4-sty Terrace/Link House (Corner)", ]
print("4-sty Terrace/Link House (Corner) Data in Bangsar:")
print(FourStory_Terrace_LinkHouse_Corner_Bangsar)
cat("Number of Rows for 4-sty Terrace/Link House (Corner) in Bangsar:", nrow(FourStory_Terrace_LinkHouse_Corner_Bangsar), "\n\n")

# Condominium (Intermediate) in Bangsar
Condominium_Intermediate_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "Condominium (Intermediate)", ]
print("Condominium (Intermediate) Data in Bangsar:")
print(Condominium_Intermediate_Bangsar)
cat("Number of Rows for Condominium (Intermediate) in Bangsar:", nrow(Condominium_Intermediate_Bangsar), "\n\n")

# 3-sty Terrace/Link House (Intermediate) in Bangsar
ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "3-sty Terrace/Link House (Intermediate)", ]
print("3-sty Terrace/Link House (Intermediate) Data in Bangsar:")
print(ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar)
cat("Number of Rows for 3-sty Terrace/Link House (Intermediate) in Bangsar:", nrow(ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar), "\n\n")

# Townhouse (EndLot) in Bangsar
Townhouse_EndLot_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "Townhouse (EndLot)", ]
print("Townhouse (EndLot) Data in Bangsar:")
print(Townhouse_EndLot_Bangsar)
cat("Number of Rows for Townhouse (EndLot) in Bangsar:", nrow(Townhouse_EndLot_Bangsar), "\n\n")

# Semi-detached House (Triplex) in Bangsar
Semi_Detached_House_Triplex_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "Semi-detached House (Triplex)", ]
print("Semi-detached House (Triplex) Data in Bangsar:")
print(Semi_Detached_House_Triplex_Bangsar)
cat("Number of Rows for Semi-detached House (Triplex) in Bangsar:", nrow(Semi_Detached_House_Triplex_Bangsar), "\n\n")

# Condominium (Duplex) in Bangsar
Condominium_Duplex_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "Condominium (Duplex)", ]
print("Condominium (Duplex) Data in Bangsar:")
print(Condominium_Duplex_Bangsar)
cat("Number of Rows for Condominium (Duplex) in Bangsar:", nrow(Condominium_Duplex_Bangsar), "\n\n")

# Bungalow (EndLot) in Bangsar
Bungalow_EndLot_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "Bungalow (EndLot)", ]
print("Bungalow (EndLot) Data in Bangsar:")
print(Bungalow_EndLot_Bangsar)
cat("Number of Rows for Bungalow (EndLot) in Bangsar:", nrow(Bungalow_EndLot_Bangsar), "\n\n")

# Serviced Residence in Bangsar
Serviced_Residence_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "Serviced Residence", ]
print("Serviced Residence Data in Bangsar:")
print(Serviced_Residence_Bangsar)
cat("Number of Rows for Serviced Residence in Bangsar:", nrow(Serviced_Residence_Bangsar), "\n\n")

# 2.5-sty Terrace/Link House (EndLot) in Bangsar
TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "2.5-sty Terrace/Link House (EndLot)", ]
print("2.5-sty Terrace/Link House (EndLot) Data in Bangsar:")
print(TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar)
cat("Number of Rows for 2.5-sty Terrace/Link House (EndLot) in Bangsar:", nrow(TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar), "\n\n")

# Townhouse in Bangsar
Townhouse_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "Townhouse", ]
print("Townhouse Data in Bangsar:")
print(Townhouse_Bangsar)
cat("Number of Rows for Townhouse in Bangsar:", nrow(Townhouse_Bangsar), "\n\n")

# Condominium (EndLot) in Bangsar
Condominium_EndLot_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "Condominium (EndLot)", ]
print("Condominium (EndLot) Data in Bangsar:")
print(Condominium_EndLot_Bangsar)
cat("Number of Rows for Condominium (EndLot) in Bangsar:", nrow(Condominium_EndLot_Bangsar), "\n\n")

# 3.5-sty Terrace/Link House in Bangsar
ThreePointFiveStory_Terrace_LinkHouse_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "3.5-sty Terrace/Link House", ]
print("3.5-sty Terrace/Link House Data in Bangsar:")
print(ThreePointFiveStory_Terrace_LinkHouse_Bangsar)
cat("Number of Rows for 3.5-sty Terrace/Link House in Bangsar:", nrow(ThreePointFiveStory_Terrace_LinkHouse_Bangsar), "\n\n")

# Residential Land in Bangsar
Residential_Land_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "Residential Land", ]
print("Residential Land Data in Bangsar:")
print(Residential_Land_Bangsar)
cat("Number of Rows for Residential Land in Bangsar:", nrow(Residential_Land_Bangsar), "\n\n")

# Condominium (Triplex) in Bangsar
Condominium_Triplex_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "Condominium (Triplex)", ]
print("Condominium (Triplex) Data in Bangsar:")
print(Condominium_Triplex_Bangsar)
cat("Number of Rows for Condominium (Triplex) in Bangsar:", nrow(Condominium_Triplex_Bangsar), "\n\n")

# 4-sty Terrace/Link House in Bangsar
FourStory_Terrace_LinkHouse_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "4-sty Terrace/Link House", ]
print("4-sty Terrace/Link House Data in Bangsar:")
print(FourStory_Terrace_LinkHouse_Bangsar)
cat("Number of Rows for 4-sty Terrace/Link House in Bangsar:", nrow(FourStory_Terrace_LinkHouse_Bangsar), "\n\n")

# Condominium (Penthouse) in Bangsar
Condominium_Penthouse_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "Condominium (Penthouse)", ]
print("Condominium (Penthouse) Data in Bangsar:")
print(Condominium_Penthouse_Bangsar)
cat("Number of Rows for Condominium (Penthouse) in Bangsar:", nrow(Condominium_Penthouse_Bangsar), "\n\n")

# 3-sty Terrace/Link House (EndLot) in Bangsar
ThreeStory_Terrace_LinkHouse_EndLot_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "3-sty Terrace/Link House (EndLot)", ]
print("3-sty Terrace/Link House (EndLot) Data in Bangsar:")
print(ThreeStory_Terrace_LinkHouse_EndLot_Bangsar)
cat("Number of Rows for 3-sty Terrace/Link House (EndLot) in Bangsar:", nrow(ThreeStory_Terrace_LinkHouse_EndLot_Bangsar), "\n\n")

# 1.5-sty Terrace/Link House (Corner) in Bangsar
OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar <- KLpropdata_Bangsar[KLpropdata_Bangsar$Property.Type == "1.5-sty Terrace/Link House (Corner)", ]
print("1.5-sty Terrace/Link House (Corner) Data in Bangsar:")
print(OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar)
cat("Number of Rows for 1.5-sty Terrace/Link House (Corner) in Bangsar:", nrow(OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar), "\n\n")

# Graph for Analysis 2
# Load the ggplot2 library
library(ggplot2)

# Create a data frame for Property Type Segmentation in Bangsar
property_counts_bangsar <- data.frame(
  Property_Type = c("Bungalow (Corner)", "Bungalow", "Condominium (Corner)", 
                    "Bungalow (Intermediate)", "Condominium", "Semi-detached House",
                    "2-sty Terrace/Link House (EndLot)", "2-sty Terrace/Link House (Intermediate)",
                    "2-sty Terrace/Link House", "3.5-sty Terrace/Link House (Intermediate)",
                    "2-sty Terrace/Link House (Corner)", "Semi-detached House (Intermediate)",
                    "4-sty Terrace/Link House (Corner)", "Condominium (Intermediate)",
                    "3-sty Terrace/Link House (Intermediate)", "Townhouse (EndLot)",
                    "Semi-detached House (Triplex)", "Condominium (Duplex)", "Bungalow (EndLot)",
                    "Serviced Residence", "2.5-sty Terrace/Link House (EndLot)", "Townhouse",
                    "Condominium (EndLot)", "3.5-sty Terrace/Link House", "Residential Land",
                    "Condominium (Triplex)", "4-sty Terrace/Link House", "Condominium (Penthouse)",
                    "3-sty Terrace/Link House (EndLot)", "1.5-sty Terrace/Link House (Corner)"),
  Count = c(
    nrow(Bungalow_Corner_Bangsar), nrow(Bungalow_Bangsar), nrow(Condominium_Corner_Bangsar),
    nrow(Bungalow_Intermediate_Bangsar), nrow(Condominium_Bangsar), nrow(Semi_Detached_House_Bangsar),
    nrow(TwoStory_Terrace_LinkHouse_EndLot_Bangsar), nrow(TwoStory_Terrace_LinkHouse_Intermediate_Bangsar),
    nrow(TwoStory_Terrace_LinkHouse_Bangsar), nrow(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar),
    nrow(TwoStory_Terrace_LinkHouse_Corner_Bangsar), nrow(Semi_Detached_House_Intermediate_Bangsar),
    nrow(FourStory_Terrace_LinkHouse_Corner_Bangsar), nrow(Condominium_Intermediate_Bangsar),
    nrow(ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar), nrow(Townhouse_EndLot_Bangsar),
    nrow(Semi_Detached_House_Triplex_Bangsar), nrow(Condominium_Duplex_Bangsar), nrow(Bungalow_EndLot_Bangsar),
    nrow(Serviced_Residence_Bangsar), nrow(TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar), nrow(Townhouse_Bangsar),
    nrow(Condominium_EndLot_Bangsar), nrow(ThreePointFiveStory_Terrace_LinkHouse_Bangsar), nrow(Residential_Land_Bangsar),
    nrow(Condominium_Triplex_Bangsar), nrow(FourStory_Terrace_LinkHouse_Bangsar), nrow(Condominium_Penthouse_Bangsar),
    nrow(ThreeStory_Terrace_LinkHouse_EndLot_Bangsar), nrow(OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar)
  )
)

# Create a lollipop chart for Property Type Segmentation in Bangsar
ggplot(property_counts_bangsar, aes(x = reorder(Property_Type, Count), y = Count)) +
  geom_segment(aes(xend = reorder(Property_Type, Count), yend = 0), color = "black") +
  geom_point(fill = "#3498db", shape = 21, color = "black", size = 3) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1),
        plot.title = element_text(hjust = 0.5)) +
  ggtitle("Property Type Segmentation in Bangsar") +
  xlab("Property Type") +
  ylab("Count") +
  coord_flip() +
  scale_y_continuous(labels = scales::comma)




# Analysis 3: Property Type Analysis Based on Furnishing Status in Bangsar

# Bungalow (Corner) in Bangsar - Partly Furnished
Bungalow_Corner_Bangsar_PartlyFurnished <- Bungalow_Corner_Bangsar[Bungalow_Corner_Bangsar$Furnishing == "Partly Furnished", ]
print("Bungalow (Corner) Data in Bangsar - Partly Furnished:")
print(Bungalow_Corner_Bangsar_PartlyFurnished)
cat("Number of Rows for Bungalow (Corner) in Bangsar - Partly Furnished:", nrow(Bungalow_Corner_Bangsar_PartlyFurnished), "\n\n")

# Bungalow (Corner) in Bangsar - Fully Furnished
Bungalow_Corner_Bangsar_FullyFurnished <- Bungalow_Corner_Bangsar[Bungalow_Corner_Bangsar$Furnishing == "Fully Furnished", ]
print("Bungalow (Corner) Data in Bangsar - Fully Furnished:")
print(Bungalow_Corner_Bangsar_FullyFurnished)
cat("Number of Rows for Bungalow (Corner) in Bangsar - Fully Furnished:", nrow(Bungalow_Corner_Bangsar_FullyFurnished), "\n\n")

# Bungalow (Corner) in Bangsar - Unfurnished
Bungalow_Corner_Bangsar_Unfurnished <- Bungalow_Corner_Bangsar[Bungalow_Corner_Bangsar$Furnishing == "Unfurnished", ]
print("Bungalow (Corner) Data in Bangsar - Unfurnished:")
print(Bungalow_Corner_Bangsar_Unfurnished)
cat("Number of Rows for Bungalow (Corner) in Bangsar - Unfurnished:", nrow(Bungalow_Corner_Bangsar_Unfurnished), "\n\n")

# Bungalow - Partly Furnished
Bungalow_PartlyFurnished <- Bungalow_Bangsar[Bungalow_Bangsar$Furnishing == "Partly Furnished", ]
print("Bungalow Data in Bangsar - Partly Furnished:")
print(Bungalow_PartlyFurnished)
cat("Number of Rows for Bungalow in Bangsar - Partly Furnished:", nrow(Bungalow_PartlyFurnished), "\n\n")

# Bungalow - Fully Furnished
Bungalow_FullyFurnished <- Bungalow_Bangsar[Bungalow_Bangsar$Furnishing == "Fully Furnished", ]
print("Bungalow Data in Bangsar - Fully Furnished:")
print(Bungalow_FullyFurnished)
cat("Number of Rows for Bungalow in Bangsar - Fully Furnished:", nrow(Bungalow_FullyFurnished), "\n\n")

# Bungalow - Unfurnished
Bungalow_Unfurnished <- Bungalow_Bangsar[Bungalow_Bangsar$Furnishing == "Unfurnished", ]
print("Bungalow Data in Bangsar - Unfurnished:")
print(Bungalow_Unfurnished)
cat("Number of Rows for Bungalow in Bangsar - Unfurnished:", nrow(Bungalow_Unfurnished), "\n\n")

# Condominium (Corner) - Partly Furnished
Condominium_Corner_Bangsar_PartlyFurnished <- Condominium_Corner_Bangsar[Condominium_Corner_Bangsar$Furnishing == "Partly Furnished", ]
print("Condominium (Corner) Data in Bangsar - Partly Furnished:")
print(Condominium_Corner_Bangsar_PartlyFurnished)
cat("Number of Rows for Condominium (Corner) in Bangsar - Partly Furnished:", nrow(Condominium_Corner_Bangsar_PartlyFurnished), "\n\n")

# Condominium (Corner) - Fully Furnished
Condominium_Corner_Bangsar_FullyFurnished <- Condominium_Corner_Bangsar[Condominium_Corner_Bangsar$Furnishing == "Fully Furnished", ]
print("Condominium (Corner) Data in Bangsar - Fully Furnished:")
print(Condominium_Corner_Bangsar_FullyFurnished)
cat("Number of Rows for Condominium (Corner) in Bangsar - Fully Furnished:", nrow(Condominium_Corner_Bangsar_FullyFurnished), "\n\n")

# Condominium (Corner) - Unfurnished
Condominium_Corner_Bangsar_Unfurnished <- Condominium_Corner_Bangsar[Condominium_Corner_Bangsar$Furnishing == "Unfurnished", ]
print("Condominium (Corner) Data in Bangsar - Unfurnished:")
print(Condominium_Corner_Bangsar_Unfurnished)
cat("Number of Rows for Condominium (Corner) in Bangsar - Unfurnished:", nrow(Condominium_Corner_Bangsar_Unfurnished), "\n\n")

# Bungalow (Intermediate) - Partly Furnished
Bungalow_Intermediate_Bangsar_PartlyFurnished <- Bungalow_Intermediate_Bangsar[Bungalow_Intermediate_Bangsar$Furnishing == "Partly Furnished", ]
print("Bungalow (Intermediate) Data in Bangsar - Partly Furnished:")
print(Bungalow_Intermediate_Bangsar_PartlyFurnished)
cat("Number of Rows for Bungalow (Intermediate) in Bangsar - Partly Furnished:", nrow(Bungalow_Intermediate_Bangsar_PartlyFurnished), "\n\n")

# Bungalow (Intermediate) - Fully Furnished
Bungalow_Intermediate_Bangsar_FullyFurnished <- Bungalow_Intermediate_Bangsar[Bungalow_Intermediate_Bangsar$Furnishing == "Fully Furnished", ]
print("Bungalow (Intermediate) Data in Bangsar - Fully Furnished:")
print(Bungalow_Intermediate_Bangsar_FullyFurnished)
cat("Number of Rows for Bungalow (Intermediate) in Bangsar - Fully Furnished:", nrow(Bungalow_Intermediate_Bangsar_FullyFurnished), "\n\n")

# Bungalow (Intermediate) - Unfurnished
Bungalow_Intermediate_Bangsar_Unfurnished <- Bungalow_Intermediate_Bangsar[Bungalow_Intermediate_Bangsar$Furnishing == "Unfurnished", ]
print("Bungalow (Intermediate) Data in Bangsar - Unfurnished:")
print(Bungalow_Intermediate_Bangsar_Unfurnished)
cat("Number of Rows for Bungalow (Intermediate) in Bangsar - Unfurnished:", nrow(Bungalow_Intermediate_Bangsar_Unfurnished), "\n\n")

# Condominium - Partly Furnished
Condominium_Bangsar_PartlyFurnished <- Condominium_Bangsar[Condominium_Bangsar$Furnishing == "Partly Furnished", ]
print("Condominium Data in Bangsar - Partly Furnished:")
print(Condominium_Bangsar_PartlyFurnished)
cat("Number of Rows for Condominium in Bangsar - Partly Furnished:", nrow(Condominium_Bangsar_PartlyFurnished), "\n\n")

# Condominium - Fully Furnished
Condominium_Bangsar_FullyFurnished <- Condominium_Bangsar[Condominium_Bangsar$Furnishing == "Fully Furnished", ]
print("Condominium Data in Bangsar - Fully Furnished:")
print(Condominium_Bangsar_FullyFurnished)
cat("Number of Rows for Condominium in Bangsar - Fully Furnished:", nrow(Condominium_Bangsar_FullyFurnished), "\n\n")

# Condominium - Unfurnished
Condominium_Bangsar_Unfurnished <- Condominium_Bangsar[Condominium_Bangsar$Furnishing == "Unfurnished", ]
print("Condominium Data in Bangsar - Unfurnished:")
print(Condominium_Bangsar_Unfurnished)
cat("Number of Rows for Condominium in Bangsar - Unfurnished:", nrow(Condominium_Bangsar_Unfurnished), "\n\n")

# Semi-detached House - Partly Furnished
Semi_Detached_House_Bangsar_PartlyFurnished <- Semi_Detached_House_Bangsar[Semi_Detached_House_Bangsar$Furnishing == "Partly Furnished", ]
print("Semi-detached House Data in Bangsar - Partly Furnished:")
print(Semi_Detached_House_Bangsar_PartlyFurnished)
cat("Number of Rows for Semi-detached House in Bangsar - Partly Furnished:", nrow(Semi_Detached_House_Bangsar_PartlyFurnished), "\n\n")

# Semi-detached House - Fully Furnished
Semi_Detached_House_Bangsar_FullyFurnished <- Semi_Detached_House_Bangsar[Semi_Detached_House_Bangsar$Furnishing == "Fully Furnished", ]
print("Semi-detached House Data in Bangsar - Fully Furnished:")
print(Semi_Detached_House_Bangsar_FullyFurnished)
cat("Number of Rows for Semi-detached House in Bangsar - Fully Furnished:", nrow(Semi_Detached_House_Bangsar_FullyFurnished), "\n\n")

# Semi-detached House - Unfurnished
Semi_Detached_House_Bangsar_Unfurnished <- Semi_Detached_House_Bangsar[Semi_Detached_House_Bangsar$Furnishing == "Unfurnished", ]
print("Semi-detached House Data in Bangsar - Unfurnished:")
print(Semi_Detached_House_Bangsar_Unfurnished)
cat("Number of Rows for Semi-detached House in Bangsar - Unfurnished:", nrow(Semi_Detached_House_Bangsar_Unfurnished), "\n\n")

# 2-sty Terrace/Link House (EndLot) - Partly Furnished
TwoStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished <- TwoStory_Terrace_LinkHouse_EndLot_Bangsar[TwoStory_Terrace_LinkHouse_EndLot_Bangsar$Furnishing == "Partly Furnished", ]
print("2-sty Terrace/Link House (EndLot) Data in Bangsar - Partly Furnished:")
print(TwoStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished)
cat("Number of Rows for 2-sty Terrace/Link House (EndLot) in Bangsar - Partly Furnished:", nrow(TwoStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished), "\n\n")

# 2-sty Terrace/Link House (EndLot) - Fully Furnished
TwoStory_Terrace_LinkHouse_EndLot_Bangsar_FullyFurnished <- TwoStory_Terrace_LinkHouse_EndLot_Bangsar[TwoStory_Terrace_LinkHouse_EndLot_Bangsar$Furnishing == "Fully Furnished", ]
print("2-sty Terrace/Link House (EndLot) Data in Bangsar - Fully Furnished:")
print(TwoStory_Terrace_LinkHouse_EndLot_Bangsar_FullyFurnished)
cat("Number of Rows for 2-sty Terrace/Link House (EndLot) in Bangsar - Fully Furnished:", nrow(TwoStory_Terrace_LinkHouse_EndLot_Bangsar_FullyFurnished), "\n\n")

# 2-sty Terrace/Link House (EndLot) - Unfurnished
TwoStory_Terrace_LinkHouse_EndLot_Bangsar_Unfurnished <- TwoStory_Terrace_LinkHouse_EndLot_Bangsar[TwoStory_Terrace_LinkHouse_EndLot_Bangsar$Furnishing == "Unfurnished", ]
print("2-sty Terrace/Link House (EndLot) Data in Bangsar - Unfurnished:")
print(TwoStory_Terrace_LinkHouse_EndLot_Bangsar_Unfurnished)
cat("Number of Rows for 2-sty Terrace/Link House (EndLot) in Bangsar - Unfurnished:", nrow(TwoStory_Terrace_LinkHouse_EndLot_Bangsar_Unfurnished), "\n\n")

# 2-sty Terrace/Link House (Intermediate) - Partly Furnished
TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished <- TwoStory_Terrace_LinkHouse_Intermediate_Bangsar[TwoStory_Terrace_LinkHouse_Intermediate_Bangsar$Furnishing == "Partly Furnished", ]
print("2-sty Terrace/Link House (Intermediate) Data in Bangsar - Partly Furnished:")
print(TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished)
cat("Number of Rows for 2-sty Terrace/Link House (Intermediate) in Bangsar - Partly Furnished:", nrow(TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished), "\n\n")

# 2-sty Terrace/Link House (Intermediate) - Fully Furnished
TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_FullyFurnished <- TwoStory_Terrace_LinkHouse_Intermediate_Bangsar[TwoStory_Terrace_LinkHouse_Intermediate_Bangsar$Furnishing == "Fully Furnished", ]
print("2-sty Terrace/Link House (Intermediate) Data in Bangsar - Fully Furnished:")
print(TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_FullyFurnished)
cat("Number of Rows for 2-sty Terrace/Link House (Intermediate) in Bangsar - Fully Furnished:", nrow(TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_FullyFurnished), "\n\n")

# 2-sty Terrace/Link House (Intermediate) - Unfurnished
TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_Unfurnished <- TwoStory_Terrace_LinkHouse_Intermediate_Bangsar[TwoStory_Terrace_LinkHouse_Intermediate_Bangsar$Furnishing == "Unfurnished", ]
print("2-sty Terrace/Link House (Intermediate) Data in Bangsar - Unfurnished:")
print(TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_Unfurnished)
cat("Number of Rows for 2-sty Terrace/Link House (Intermediate) in Bangsar - Unfurnished:", nrow(TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_Unfurnished), "\n\n")

# 2-sty Terrace/Link House - Partly Furnished
TwoStory_Terrace_LinkHouse_Bangsar_PartlyFurnished <- TwoStory_Terrace_LinkHouse_Bangsar[TwoStory_Terrace_LinkHouse_Bangsar$Furnishing == "Partly Furnished", ]
print("2-sty Terrace/Link House Data in Bangsar - Partly Furnished:")
print(TwoStory_Terrace_LinkHouse_Bangsar_PartlyFurnished)
cat("Number of Rows for 2-sty Terrace/Link House in Bangsar - Partly Furnished:", nrow(TwoStory_Terrace_LinkHouse_Bangsar_PartlyFurnished), "\n\n")

# 2-sty Terrace/Link House - Fully Furnished
TwoStory_Terrace_LinkHouse_Bangsar_FullyFurnished <- TwoStory_Terrace_LinkHouse_Bangsar[TwoStory_Terrace_LinkHouse_Bangsar$Furnishing == "Fully Furnished", ]
print("2-sty Terrace/Link House Data in Bangsar - Fully Furnished:")
print(TwoStory_Terrace_LinkHouse_Bangsar_FullyFurnished)
cat("Number of Rows for 2-sty Terrace/Link House in Bangsar - Fully Furnished:", nrow(TwoStory_Terrace_LinkHouse_Bangsar_FullyFurnished), "\n\n")

# 2-sty Terrace/Link House - Unfurnished
TwoStory_Terrace_LinkHouse_Bangsar_Unfurnished <- TwoStory_Terrace_LinkHouse_Bangsar[TwoStory_Terrace_LinkHouse_Bangsar$Furnishing == "Unfurnished", ]
print("2-sty Terrace/Link House Data in Bangsar - Unfurnished:")
print(TwoStory_Terrace_LinkHouse_Bangsar_Unfurnished)
cat("Number of Rows for 2-sty Terrace/Link House in Bangsar - Unfurnished:", nrow(TwoStory_Terrace_LinkHouse_Bangsar_Unfurnished), "\n\n")

# ThreePointFiveStory Terrace/Link House (Intermediate) - Partly Furnished
ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished <- ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar[ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar$Furnishing == "Partly Furnished", ]
print("3.5-sty Terrace/Link House (Intermediate) Data in Bangsar - Partly Furnished:")
print(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished)
cat("Number of Rows for 3.5-sty Terrace/Link House (Intermediate) in Bangsar - Partly Furnished:", nrow(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished), "\n\n")

# ThreePointFiveStory Terrace/Link House (Intermediate) - Fully Furnished
ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_FullyFurnished <- ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar[ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar$Furnishing == "Fully Furnished", ]
print("3.5-sty Terrace/Link House (Intermediate) Data in Bangsar - Fully Furnished:")
print(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_FullyFurnished)
cat("Number of Rows for 3.5-sty Terrace/Link House (Intermediate) in Bangsar - Fully Furnished:", nrow(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_FullyFurnished), "\n\n")

# ThreePointFiveStory Terrace/Link House (Intermediate) - Unfurnished
ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_Unfurnished <- ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar[ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar$Furnishing == "Unfurnished", ]
print("3.5-sty Terrace/Link House (Intermediate) Data in Bangsar - Unfurnished:")
print(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_Unfurnished)
cat("Number of Rows for 3.5-sty Terrace/Link House (Intermediate) in Bangsar - Unfurnished:", nrow(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_Unfurnished), "\n\n")

# 2-sty Terrace/Link House (Corner) - Partly Furnished
TwoStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished <- TwoStory_Terrace_LinkHouse_Corner_Bangsar[TwoStory_Terrace_LinkHouse_Corner_Bangsar$Furnishing == "Partly Furnished", ]
print("2-sty Terrace/Link House (Corner) Data in Bangsar - Partly Furnished:")
print(TwoStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished)
cat("Number of Rows for 2-sty Terrace/Link House (Corner) in Bangsar - Partly Furnished:", nrow(TwoStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished), "\n\n")

# 2-sty Terrace/Link House (Corner) - Fully Furnished
TwoStory_Terrace_LinkHouse_Corner_Bangsar_FullyFurnished <- TwoStory_Terrace_LinkHouse_Corner_Bangsar[TwoStory_Terrace_LinkHouse_Corner_Bangsar$Furnishing == "Fully Furnished", ]
print("2-sty Terrace/Link House (Corner) Data in Bangsar - Fully Furnished:")
print(TwoStory_Terrace_LinkHouse_Corner_Bangsar_FullyFurnished)
cat("Number of Rows for 2-sty Terrace/Link House (Corner) in Bangsar - Fully Furnished:", nrow(TwoStory_Terrace_LinkHouse_Corner_Bangsar_FullyFurnished), "\n\n")

# 2-sty Terrace/Link House (Corner) - Unfurnished
TwoStory_Terrace_LinkHouse_Corner_Bangsar_Unfurnished <- TwoStory_Terrace_LinkHouse_Corner_Bangsar[TwoStory_Terrace_LinkHouse_Corner_Bangsar$Furnishing == "Unfurnished", ]
print("2-sty Terrace/Link House (Corner) Data in Bangsar - Unfurnished:")
print(TwoStory_Terrace_LinkHouse_Corner_Bangsar_Unfurnished)
cat("Number of Rows for 2-sty Terrace/Link House (Corner) in Bangsar - Unfurnished:", nrow(TwoStory_Terrace_LinkHouse_Corner_Bangsar_Unfurnished), "\n\n")

# Semi-detached House (Intermediate) - Partly Furnished
Semi_Detached_House_Intermediate_Bangsar_PartlyFurnished <- Semi_Detached_House_Intermediate_Bangsar[Semi_Detached_House_Intermediate_Bangsar$Furnishing == "Partly Furnished", ]
print("Semi-detached House (Intermediate) Data in Bangsar - Partly Furnished:")
print(Semi_Detached_House_Intermediate_Bangsar_PartlyFurnished)
cat("Number of Rows for Semi-detached House (Intermediate) in Bangsar - Partly Furnished:", nrow(Semi_Detached_House_Intermediate_Bangsar_PartlyFurnished), "\n\n")

# Semi-detached House (Intermediate) - Fully Furnished
Semi_Detached_House_Intermediate_Bangsar_FullyFurnished <- Semi_Detached_House_Intermediate_Bangsar[Semi_Detached_House_Intermediate_Bangsar$Furnishing == "Fully Furnished", ]
print("Semi-detached House (Intermediate) Data in Bangsar - Fully Furnished:")
print(Semi_Detached_House_Intermediate_Bangsar_FullyFurnished)
cat("Number of Rows for Semi-detached House (Intermediate) in Bangsar - Fully Furnished:", nrow(Semi_Detached_House_Intermediate_Bangsar_FullyFurnished), "\n\n")

# Semi-detached House (Intermediate) - Unfurnished
Semi_Detached_House_Intermediate_Bangsar_Unfurnished <- Semi_Detached_House_Intermediate_Bangsar[Semi_Detached_House_Intermediate_Bangsar$Furnishing == "Unfurnished", ]
print("Semi-detached House (Intermediate) Data in Bangsar - Unfurnished:")
print(Semi_Detached_House_Intermediate_Bangsar_Unfurnished)
cat("Number of Rows for Semi-detached House (Intermediate) in Bangsar - Unfurnished:", nrow(Semi_Detached_House_Intermediate_Bangsar_Unfurnished), "\n\n")

# 4-sty Terrace/Link House (Corner) - Partly Furnished
FourStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished <- FourStory_Terrace_LinkHouse_Corner_Bangsar[FourStory_Terrace_LinkHouse_Corner_Bangsar$Furnishing == "Partly Furnished", ]
print("4-sty Terrace/Link House (Corner) Data in Bangsar - Partly Furnished:")
print(FourStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished)
cat("Number of Rows for 4-sty Terrace/Link House (Corner) in Bangsar - Partly Furnished:", nrow(FourStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished), "\n\n")

# 4-sty Terrace/Link House (Corner) - Fully Furnished
FourStory_Terrace_LinkHouse_Corner_Bangsar_FullyFurnished <- FourStory_Terrace_LinkHouse_Corner_Bangsar[FourStory_Terrace_LinkHouse_Corner_Bangsar$Furnishing == "Fully Furnished", ]
print("4-sty Terrace/Link House (Corner) Data in Bangsar - Fully Furnished:")
print(FourStory_Terrace_LinkHouse_Corner_Bangsar_FullyFurnished)
cat("Number of Rows for 4-sty Terrace/Link House (Corner) in Bangsar - Fully Furnished:", nrow(FourStory_Terrace_LinkHouse_Corner_Bangsar_FullyFurnished), "\n\n")

# 4-sty Terrace/Link House (Corner) - Unfurnished
FourStory_Terrace_LinkHouse_Corner_Bangsar_Unfurnished <- FourStory_Terrace_LinkHouse_Corner_Bangsar[FourStory_Terrace_LinkHouse_Corner_Bangsar$Furnishing == "Unfurnished", ]
print("4-sty Terrace/Link House (Corner) Data in Bangsar - Unfurnished:")
print(FourStory_Terrace_LinkHouse_Corner_Bangsar_Unfurnished)
cat("Number of Rows for 4-sty Terrace/Link House (Corner) in Bangsar - Unfurnished:", nrow(FourStory_Terrace_LinkHouse_Corner_Bangsar_Unfurnished), "\n\n")

# Condominium (Intermediate) - Partly Furnished
Condominium_Intermediate_Bangsar_PartlyFurnished <- KLpropdata[
  KLpropdata$Location == "Bangsar, Kuala Lumpur" &
    KLpropdata$PropertyType == "Condominium (Intermediate)" &
    KLpropdata$Furnishing == "Partly Furnished", ]

print("Condominium (Intermediate) Data in Bangsar - Partly Furnished:")
print(Condominium_Intermediate_Bangsar_PartlyFurnished)
cat("Number of Rows for Condominium (Intermediate) in Bangsar - Partly Furnished:", nrow(Condominium_Intermediate_Bangsar_PartlyFurnished), "\n\n")

# Condominium (Intermediate) - Fully Furnished
Condominium_Intermediate_Bangsar_FullyFurnished <- KLpropdata[
  KLpropdata$Location == "Bangsar, Kuala Lumpur" &
    KLpropdata$PropertyType == "Condominium (Intermediate)" &
    KLpropdata$Furnishing == "Fully Furnished", ]

print("Condominium (Intermediate) Data in Bangsar - Fully Furnished:")
print(Condominium_Intermediate_Bangsar_FullyFurnished)
cat("Number of Rows for Condominium (Intermediate) in Bangsar - Fully Furnished:", nrow(Condominium_Intermediate_Bangsar_FullyFurnished), "\n\n")

# Condominium (Intermediate) - Unfurnished
Condominium_Intermediate_Bangsar_Unfurnished <- KLpropdata[
  KLpropdata$Location == "Bangsar, Kuala Lumpur" &
    KLpropdata$PropertyType == "Condominium (Intermediate)" &
    KLpropdata$Furnishing == "Unfurnished", ]

print("Condominium (Intermediate) Data in Bangsar - Unfurnished:")
print(Condominium_Intermediate_Bangsar_Unfurnished)
cat("Number of Rows for Condominium (Intermediate) in Bangsar - Unfurnished:", nrow(Condominium_Intermediate_Bangsar_Unfurnished), "\n\n")

# 3-sty Terrace/Link House (Intermediate) - Partly Furnished
ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished <- ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar[ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar$Furnishing == "Partly Furnished", ]
print("3-sty Terrace/Link House (Intermediate) Data in Bangsar - Partly Furnished:")
print(ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished)
cat("Number of Rows for 3-sty Terrace/Link House (Intermediate) in Bangsar - Partly Furnished:", nrow(ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished), "\n\n")

# 3-sty Terrace/Link House (Intermediate) - Fully Furnished
ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_FullyFurnished <- ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar[ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar$Furnishing == "Fully Furnished", ]
print("3-sty Terrace/Link House (Intermediate) Data in Bangsar - Fully Furnished:")
print(ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_FullyFurnished)
cat("Number of Rows for 3-sty Terrace/Link House (Intermediate) in Bangsar - Fully Furnished:", nrow(ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_FullyFurnished), "\n\n")

# 3-sty Terrace/Link House (Intermediate) - Unfurnished
ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_Unfurnished <- ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar[ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar$Furnishing == "Unfurnished", ]
print("3-sty Terrace/Link House (Intermediate) Data in Bangsar - Unfurnished:")
print(ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_Unfurnished)
cat("Number of Rows for 3-sty Terrace/Link House (Intermediate) in Bangsar - Unfurnished:", nrow(ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_Unfurnished), "\n\n")

# Townhouse (EndLot) - Partly Furnished
Townhouse_EndLot_Bangsar_PartlyFurnished <- Townhouse_EndLot_Bangsar[Townhouse_EndLot_Bangsar$Furnishing == "Partly Furnished", ]
print("Townhouse (EndLot) Data in Bangsar - Partly Furnished:")
print(Townhouse_EndLot_Bangsar_PartlyFurnished)
cat("Number of Rows for Townhouse (EndLot) in Bangsar - Partly Furnished:", nrow(Townhouse_EndLot_Bangsar_PartlyFurnished), "\n\n")

# Townhouse (EndLot) - Fully Furnished
Townhouse_EndLot_Bangsar_FullyFurnished <- Townhouse_EndLot_Bangsar[Townhouse_EndLot_Bangsar$Furnishing == "Fully Furnished", ]
print("Townhouse (EndLot) Data in Bangsar - Fully Furnished:")
print(Townhouse_EndLot_Bangsar_FullyFurnished)
cat("Number of Rows for Townhouse (EndLot) in Bangsar - Fully Furnished:", nrow(Townhouse_EndLot_Bangsar_FullyFurnished), "\n\n")

# Townhouse (EndLot) - Unfurnished
Townhouse_EndLot_Bangsar_Unfurnished <- Townhouse_EndLot_Bangsar[Townhouse_EndLot_Bangsar$Furnishing == "Unfurnished", ]
print("Townhouse (EndLot) Data in Bangsar - Unfurnished:")
print(Townhouse_EndLot_Bangsar_Unfurnished)
cat("Number of Rows for Townhouse (EndLot) in Bangsar - Unfurnished:", nrow(Townhouse_EndLot_Bangsar_Unfurnished), "\n\n")

# Semi-detached House (Triplex) - Partly Furnished
Semi_Detached_House_Triplex_Bangsar_PartlyFurnished <- Semi_Detached_House_Triplex_Bangsar[Semi_Detached_House_Triplex_Bangsar$Furnishing == "Partly Furnished", ]
print("Semi-detached House (Triplex) Data in Bangsar - Partly Furnished:")
print(Semi_Detached_House_Triplex_Bangsar_PartlyFurnished)
cat("Number of Rows for Semi-detached House (Triplex) in Bangsar - Partly Furnished:", nrow(Semi_Detached_House_Triplex_Bangsar_PartlyFurnished), "\n\n")

# Semi-detached House (Triplex) - Fully Furnished
Semi_Detached_House_Triplex_Bangsar_FullyFurnished <- Semi_Detached_House_Triplex_Bangsar[Semi_Detached_House_Triplex_Bangsar$Furnishing == "Fully Furnished", ]
print("Semi-detached House (Triplex) Data in Bangsar - Fully Furnished:")
print(Semi_Detached_House_Triplex_Bangsar_FullyFurnished)
cat("Number of Rows for Semi-detached House (Triplex) in Bangsar - Fully Furnished:", nrow(Semi_Detached_House_Triplex_Bangsar_FullyFurnished), "\n\n")

# Semi-detached House (Triplex) - Unfurnished
Semi_Detached_House_Triplex_Bangsar_Unfurnished <- Semi_Detached_House_Triplex_Bangsar[Semi_Detached_House_Triplex_Bangsar$Furnishing == "Unfurnished", ]
print("Semi-detached House (Triplex) Data in Bangsar - Unfurnished:")
print(Semi_Detached_House_Triplex_Bangsar_Unfurnished)
cat("Number of Rows for Semi-detached House (Triplex) in Bangsar - Unfurnished:", nrow(Semi_Detached_House_Triplex_Bangsar_Unfurnished), "\n\n")

# Condominium (Duplex) - Partly Furnished
Condominium_Duplex_Bangsar_PartlyFurnished <- Condominium_Duplex_Bangsar[Condominium_Duplex_Bangsar$Furnishing == "Partly Furnished", ]
print("Condominium (Duplex) Data in Bangsar - Partly Furnished:")
print(Condominium_Duplex_Bangsar_PartlyFurnished)
cat("Number of Rows for Condominium (Duplex) in Bangsar - Partly Furnished:", nrow(Condominium_Duplex_Bangsar_PartlyFurnished), "\n\n")

# Condominium (Duplex) - Fully Furnished
Condominium_Duplex_Bangsar_FullyFurnished <- Condominium_Duplex_Bangsar[Condominium_Duplex_Bangsar$Furnishing == "Fully Furnished", ]
print("Condominium (Duplex) Data in Bangsar - Fully Furnished:")
print(Condominium_Duplex_Bangsar_FullyFurnished)
cat("Number of Rows for Condominium (Duplex) in Bangsar - Fully Furnished:", nrow(Condominium_Duplex_Bangsar_FullyFurnished), "\n\n")

# Condominium (Duplex) - Unfurnished
Condominium_Duplex_Bangsar_Unfurnished <- Condominium_Duplex_Bangsar[Condominium_Duplex_Bangsar$Furnishing == "Unfurnished", ]
print("Condominium (Duplex) Data in Bangsar - Unfurnished:")
print(Condominium_Duplex_Bangsar_Unfurnished)
cat("Number of Rows for Condominium (Duplex) in Bangsar - Unfurnished:", nrow(Condominium_Duplex_Bangsar_Unfurnished), "\n\n")

# Bungalow (EndLot) - Partly Furnished
Bungalow_EndLot_Bangsar_PartlyFurnished <- Bungalow_EndLot_Bangsar[Bungalow_EndLot_Bangsar$Furnishing == "Partly Furnished", ]
print("Bungalow (EndLot) Data in Bangsar - Partly Furnished:")
print(Bungalow_EndLot_Bangsar_PartlyFurnished)
cat("Number of Rows for Bungalow (EndLot) in Bangsar - Partly Furnished:", nrow(Bungalow_EndLot_Bangsar_PartlyFurnished), "\n\n")

# Bungalow (EndLot) - Fully Furnished
Bungalow_EndLot_Bangsar_FullyFurnished <- Bungalow_EndLot_Bangsar[Bungalow_EndLot_Bangsar$Furnishing == "Fully Furnished", ]
print("Bungalow (EndLot) Data in Bangsar - Fully Furnished:")
print(Bungalow_EndLot_Bangsar_FullyFurnished)
cat("Number of Rows for Bungalow (EndLot) in Bangsar - Fully Furnished:", nrow(Bungalow_EndLot_Bangsar_FullyFurnished), "\n\n")

# Bungalow (EndLot) - Unfurnished
Bungalow_EndLot_Bangsar_Unfurnished <- Bungalow_EndLot_Bangsar[Bungalow_EndLot_Bangsar$Furnishing == "Unfurnished", ]
print("Bungalow (EndLot) Data in Bangsar - Unfurnished:")
print(Bungalow_EndLot_Bangsar_Unfurnished)
cat("Number of Rows for Bungalow (EndLot) in Bangsar - Unfurnished:", nrow(Bungalow_EndLot_Bangsar_Unfurnished), "\n\n")

# Serviced Residence - Partly Furnished
Serviced_Residence_Bangsar_PartlyFurnished <- Serviced_Residence_Bangsar[Serviced_Residence_Bangsar$Furnishing == "Partly Furnished", ]
print("Serviced Residence Data in Bangsar - Partly Furnished:")
print(Serviced_Residence_Bangsar_PartlyFurnished)
cat("Number of Rows for Serviced Residence in Bangsar - Partly Furnished:", nrow(Serviced_Residence_Bangsar_PartlyFurnished), "\n\n")

# Serviced Residence - Fully Furnished
Serviced_Residence_Bangsar_FullyFurnished <- Serviced_Residence_Bangsar[Serviced_Residence_Bangsar$Furnishing == "Fully Furnished", ]
print("Serviced Residence Data in Bangsar - Fully Furnished:")
print(Serviced_Residence_Bangsar_FullyFurnished)
cat("Number of Rows for Serviced Residence in Bangsar - Fully Furnished:", nrow(Serviced_Residence_Bangsar_FullyFurnished), "\n\n")

# Serviced Residence - Unfurnished
Serviced_Residence_Bangsar_Unfurnished <- Serviced_Residence_Bangsar[Serviced_Residence_Bangsar$Furnishing == "Unfurnished", ]
print("Serviced Residence Data in Bangsar - Unfurnished:")
print(Serviced_Residence_Bangsar_Unfurnished)
cat("Number of Rows for Serviced Residence in Bangsar - Unfurnished:", nrow(Serviced_Residence_Bangsar_Unfurnished), "\n\n")

# 2.5-sty Terrace/Link House (EndLot) - Partly Furnished
TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished <- TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar[TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar$Furnishing == "Partly Furnished", ]
print("2.5-sty Terrace/Link House (EndLot) Data in Bangsar - Partly Furnished:")
print(TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished)
cat("Number of Rows for 2.5-sty Terrace/Link House (EndLot) in Bangsar - Partly Furnished:", nrow(TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished), "\n\n")

# 2.5-sty Terrace/Link House (EndLot) - Fully Furnished
TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar_FullyFurnished <- TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar[TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar$Furnishing == "Fully Furnished", ]
print("2.5-sty Terrace/Link House (EndLot) Data in Bangsar - Fully Furnished:")
print(TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar_FullyFurnished)
cat("Number of Rows for 2.5-sty Terrace/Link House (EndLot) in Bangsar - Fully Furnished:", nrow(TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar_FullyFurnished), "\n\n")

# 2.5-sty Terrace/Link House (EndLot) - Unfurnished
TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar_Unfurnished <- TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar[TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar$Furnishing == "Unfurnished", ]
print("2.5-sty Terrace/Link House (EndLot) Data in Bangsar - Unfurnished:")
print(TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar_Unfurnished)
cat("Number of Rows for 2.5-sty Terrace/Link House (EndLot) in Bangsar - Unfurnished:", nrow(TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar_Unfurnished), "\n\n")

# Townhouse - Partly Furnished
Townhouse_Bangsar_PartlyFurnished <- Townhouse_Bangsar[Townhouse_Bangsar$Furnishing == "Partly Furnished", ]
print("Townhouse Data in Bangsar - Partly Furnished:")
print(Townhouse_Bangsar_PartlyFurnished)
cat("Number of Rows for Townhouse in Bangsar - Partly Furnished:", nrow(Townhouse_Bangsar_PartlyFurnished), "\n\n")

# Townhouse - Fully Furnished
Townhouse_Bangsar_FullyFurnished <- Townhouse_Bangsar[Townhouse_Bangsar$Furnishing == "Fully Furnished", ]
print("Townhouse Data in Bangsar - Fully Furnished:")
print(Townhouse_Bangsar_FullyFurnished)
cat("Number of Rows for Townhouse in Bangsar - Fully Furnished:", nrow(Townhouse_Bangsar_FullyFurnished), "\n\n")

# Townhouse - Unfurnished
Townhouse_Bangsar_Unfurnished <- Townhouse_Bangsar[Townhouse_Bangsar$Furnishing == "Unfurnished", ]
print("Townhouse Data in Bangsar - Unfurnished:")
print(Townhouse_Bangsar_Unfurnished)
cat("Number of Rows for Townhouse in Bangsar - Unfurnished:", nrow(Townhouse_Bangsar_Unfurnished), "\n\n")

# Condominium (EndLot) - Partly Furnished
Condominium_EndLot_Bangsar_PartlyFurnished <- Condominium_EndLot_Bangsar[Condominium_EndLot_Bangsar$Furnishing == "Partly Furnished", ]
print("Condominium (EndLot) Data in Bangsar - Partly Furnished:")
print(Condominium_EndLot_Bangsar_PartlyFurnished)
cat("Number of Rows for Condominium (EndLot) in Bangsar - Partly Furnished:", nrow(Condominium_EndLot_Bangsar_PartlyFurnished), "\n\n")

# Condominium (EndLot) - Fully Furnished
Condominium_EndLot_Bangsar_FullyFurnished <- Condominium_EndLot_Bangsar[Condominium_EndLot_Bangsar$Furnishing == "Fully Furnished", ]
print("Condominium (EndLot) Data in Bangsar - Fully Furnished:")
print(Condominium_EndLot_Bangsar_FullyFurnished)
cat("Number of Rows for Condominium (EndLot) in Bangsar - Fully Furnished:", nrow(Condominium_EndLot_Bangsar_FullyFurnished), "\n\n")

# Condominium (EndLot) - Unfurnished
Condominium_EndLot_Bangsar_Unfurnished <- Condominium_EndLot_Bangsar[Condominium_EndLot_Bangsar$Furnishing == "Unfurnished", ]
print("Condominium (EndLot) Data in Bangsar - Unfurnished:")
print(Condominium_EndLot_Bangsar_Unfurnished)
cat("Number of Rows for Condominium (EndLot) in Bangsar - Unfurnished:", nrow(Condominium_EndLot_Bangsar_Unfurnished), "\n\n")

# Condominium - Triplex - Partly Furnished
Condominium_Triplex_Bangsar_PartlyFurnished <- Condominium_Triplex_Bangsar[Condominium_Triplex_Bangsar$Furnishing == "Partly Furnished", ]
print("Condominium (Intermediate) - Triplex Data in Bangsar - Partly Furnished:")
print(Condominium_Triplex_Bangsar_PartlyFurnished)
cat("Number of Rows for Condominium (Intermediate) - Triplex in Bangsar - Partly Furnished:", nrow(Condominium_Triplex_Bangsar_PartlyFurnished), "\n\n")

# Condominium - Triplex - Fully Furnished
Condominium_Triplex_Bangsar_FullyFurnished <- Condominium_Triplex_Bangsar[Condominium_Triplex_Bangsar$Furnishing == "Fully Furnished", ]
print("Condominium (Intermediate) - Triplex Data in Bangsar - Fully Furnished:")
print(Condominium_Triplex_Bangsar_FullyFurnished)
cat("Number of Rows for Condominium (Intermediate) - Triplex in Bangsar - Fully Furnished:", nrow(Condominium_Triplex_Bangsar_FullyFurnished), "\n\n")

# Condominium - Triplex - Unfurnished
Condominium_Triplex_Bangsar_Unfurnished <- Condominium_Triplex_Bangsar[Condominium_Triplex_Bangsar$Furnishing == "Unfurnished", ]
print("Condominium (Intermediate) - Triplex Data in Bangsar - Unfurnished:")
print(Condominium_Triplex_Bangsar_Unfurnished)
cat("Number of Rows for Condominium (Intermediate) - Triplex in Bangsar - Unfurnished:", nrow(Condominium_Triplex_Bangsar_Unfurnished), "\n\n")

# 3.5-sty Terrace/Link House - Partly Furnished
ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished <- ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar[ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar$Furnishing == "Partly Furnished", ]
print("3.5-sty Terrace/Link House Data in Bangsar - Partly Furnished:")
print(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished)
cat("Number of Rows for 3.5-sty Terrace/Link House in Bangsar - Partly Furnished:", nrow(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished), "\n\n")

# 3.5-sty Terrace/Link House - Fully Furnished
ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_FullyFurnished <- ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar[ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar$Furnishing == "Fully Furnished", ]
print("3.5-sty Terrace/Link House Data in Bangsar - Fully Furnished:")
print(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_FullyFurnished)
cat("Number of Rows for 3.5-sty Terrace/Link House in Bangsar - Fully Furnished:", nrow(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_FullyFurnished), "\n\n")

# 3.5-sty Terrace/Link House - Unfurnished
ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_Unfurnished <- ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar[ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar$Furnishing == "Unfurnished", ]
print("3.5-sty Terrace/Link House Data in Bangsar - Unfurnished:")
print(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_Unfurnished)
cat("Number of Rows for 3.5-sty Terrace/Link House in Bangsar - Unfurnished:", nrow(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_Unfurnished), "\n\n")


# 1.5-sty Terrace/Link House (Corner) - Partly Furnished
OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished <- OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar[OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar$Furnishing == "Partly Furnished", ]
print("1.5-sty Terrace/Link House (Corner) Data in Bangsar - Partly Furnished:")
print(OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished)
cat("Number of Rows for 1.5-sty Terrace/Link House (Corner) in Bangsar - Partly Furnished:", nrow(OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished), "\n\n")

# 1.5-sty Terrace/Link House (Corner) - Fully Furnished
OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar_FullyFurnished <- OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar[OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar$Furnishing == "Fully Furnished", ]
print("1.5-sty Terrace/Link House (Corner) Data in Bangsar - Fully Furnished:")
print(OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar_FullyFurnished)
cat("Number of Rows for 1.5-sty Terrace/Link House (Corner) in Bangsar - Fully Furnished:", nrow(OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar_FullyFurnished), "\n\n")

# 1.5-sty Terrace/Link House (Corner) - Unfurnished
OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar_Unfurnished <- OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar[OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar$Furnishing == "Unfurnished", ]
print("1.5-sty Terrace/Link House (Corner) Data in Bangsar - Unfurnished:")
print(OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar_Unfurnished)
cat("Number of Rows for 1.5-sty Terrace/Link House (Corner) in Bangsar - Unfurnished:", nrow(OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar_Unfurnished), "\n\n")


# Graph for Analysis 3

# Combine all the data frames into a single data frame
all_data_bangsar <- rbind(
  Bungalow_Corner_Bangsar_PartlyFurnished,
  Bungalow_Corner_Bangsar_FullyFurnished,
  Bungalow_Corner_Bangsar_Unfurnished,
  Bungalow_PartlyFurnished,
  Bungalow_FullyFurnished,
  Bungalow_Unfurnished,
  Condominium_Corner_Bangsar_PartlyFurnished,
  Condominium_Corner_Bangsar_FullyFurnished,
  Condominium_Corner_Bangsar_Unfurnished,
  Bungalow_Intermediate_Bangsar_PartlyFurnished,
  Bungalow_Intermediate_Bangsar_FullyFurnished,
  Bungalow_Intermediate_Bangsar_Unfurnished,
  Semi_Detached_House_Bangsar_PartlyFurnished,
  Semi_Detached_House_Bangsar_FullyFurnished,
  Semi_Detached_House_Bangsar_Unfurnished,
  TwoStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished,
  TwoStory_Terrace_LinkHouse_EndLot_Bangsar_FullyFurnished,
  TwoStory_Terrace_LinkHouse_EndLot_Bangsar_Unfurnished,
  TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished,
  TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_FullyFurnished,
  TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_Unfurnished,
  TwoStory_Terrace_LinkHouse_Bangsar_PartlyFurnished,
  TwoStory_Terrace_LinkHouse_Bangsar_FullyFurnished,
  TwoStory_Terrace_LinkHouse_Bangsar_Unfurnished,
  ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished,
  ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_FullyFurnished,
  ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_Unfurnished,
  TwoStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished,
  TwoStory_Terrace_LinkHouse_Corner_Bangsar_FullyFurnished,
  TwoStory_Terrace_LinkHouse_Corner_Bangsar_Unfurnished,
  Semi_Detached_House_Intermediate_Bangsar_PartlyFurnished,
  Semi_Detached_House_Intermediate_Bangsar_FullyFurnished,
  Semi_Detached_House_Intermediate_Bangsar_Unfurnished,
  FourStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished,
  FourStory_Terrace_LinkHouse_Corner_Bangsar_FullyFurnished,
  FourStory_Terrace_LinkHouse_Corner_Bangsar_Unfurnished,
  Condominium_Intermediate_Bangsar_PartlyFurnished,
  Condominium_Intermediate_Bangsar_FullyFurnished,
  Condominium_Intermediate_Bangsar_Unfurnished,
  Bungalow_EndLot_Bangsar_FullyFurnished,
  Bungalow_EndLot_Bangsar_Unfurnished,
  FourStory_Terrace_LinkHouse_Corner_Bangsar_Unfurnished,
  ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished,
  ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_FullyFurnished,
  ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_Unfurnished,
  Townhouse_EndLot_Bangsar_PartlyFurnished,
  Townhouse_EndLot_Bangsar_FullyFurnished,
  Townhouse_EndLot_Bangsar_Unfurnished,
  Semi_Detached_House_Triplex_Bangsar_PartlyFurnished,
  Semi_Detached_House_Triplex_Bangsar_FullyFurnished,
  Semi_Detached_House_Triplex_Bangsar_Unfurnished,
  Condominium_Duplex_Bangsar_PartlyFurnished,
  Condominium_Duplex_Bangsar_FullyFurnished,
  Condominium_Duplex_Bangsar_Unfurnished,
  Bungalow_EndLot_Bangsar_PartlyFurnished,
  TwoStory_Terrace_LinkHouse_Bangsar_PartlyFurnished,
  TwoStory_Terrace_LinkHouse_Bangsar_FullyFurnished,
  TwoStory_Terrace_LinkHouse_Bangsar_Unfurnished,
  ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished,
  ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_FullyFurnished,
  ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_Unfurnished,
  TwoStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished,
  TwoStory_Terrace_LinkHouse_Corner_Bangsar_FullyFurnished,
  TwoStory_Terrace_LinkHouse_Corner_Bangsar_Unfurnished,
  Semi_Detached_House_Intermediate_Bangsar_PartlyFurnished,
  Semi_Detached_House_Intermediate_Bangsar_FullyFurnished,
  Semi_Detached_House_Intermediate_Bangsar_Unfurnished,
  FourStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished,
  FourStory_Terrace_LinkHouse_Corner_Bangsar_FullyFurnished,
  FourStory_Terrace_LinkHouse_Corner_Bangsar_Unfurnished,
  Condominium_Bangsar_PartlyFurnished,
  Condominium_Bangsar_FullyFurnished,
  Condominium_Bangsar_Unfurnished,
  Semi_Detached_House_Bangsar_PartlyFurnished,
  Semi_Detached_House_Bangsar_FullyFurnished,
  Semi_Detached_House_Bangsar_Unfurnished,
  TwoStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished,
  TwoStory_Terrace_LinkHouse_EndLot_Bangsar_FullyFurnished
)

# Assuming you have a variable in your data frame named 'Price' representing the prices of the properties
# Replace 'Price' with the actual variable name in your data frame

library(ggplot2)

# Create a bar plot
ggplot(all_data_bangsar, aes(x = Property.Type, y = Price, fill = Furnishing)) +
  geom_bar(stat = "identity", position = "dodge") +
  labs(title = "Property Prices in Bangsar",
       x = "Property Type",
       y = "Price",
       fill = "Furnishing Status") +
  theme_minimal()


# Analysis 4: Property Analysis Based on Size

# Define size ranges
size_range_1 <- 3500
size_range_2_min <- 3500
size_range_2_max <- 5000
size_range_3_min <- 5000

# Bungalow (Corner) - Partly Furnished
Bungalow_Corner_Bangsar_PartlyFurnished_Size1 <- Bungalow_Corner_Bangsar_PartlyFurnished[Bungalow_Corner_Bangsar_PartlyFurnished$Size_Value < size_range_1, ]
Bungalow_Corner_Bangsar_PartlyFurnished_Size2 <- Bungalow_Corner_Bangsar_PartlyFurnished[Bungalow_Corner_Bangsar_PartlyFurnished$Size_Value >= size_range_2_min & Bungalow_Corner_Bangsar_PartlyFurnished$Size_Value <= size_range_2_max, ]
Bungalow_Corner_Bangsar_PartlyFurnished_Size3 <- Bungalow_Corner_Bangsar_PartlyFurnished[Bungalow_Corner_Bangsar_PartlyFurnished$Size_Value > size_range_3_min, ]

# Print the filtered data and row counts for Bungalow (Corner) - Partly Furnished
cat("Bungalow (Corner) - Partly Furnished - Size < 3500:\n")
print(Bungalow_Corner_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(Bungalow_Corner_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("Bungalow (Corner) - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(Bungalow_Corner_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(Bungalow_Corner_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("Bungalow (Corner) - Partly Furnished - Size > 5000:\n")
print(Bungalow_Corner_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(Bungalow_Corner_Bangsar_PartlyFurnished_Size3), "\n\n")

# Bungalow (Bangsar) - Partly Furnished
Bungalow_PartlyFurnished_Size1 <- Bungalow_PartlyFurnished[Bungalow_PartlyFurnished$Size_Value < size_range_1, ]
Bungalow_PartlyFurnished_Size2 <- Bungalow_PartlyFurnished[Bungalow_PartlyFurnished$Size_Value >= size_range_2_min & Bungalow_PartlyFurnished$Size_Value <= size_range_2_max, ]
Bungalow_PartlyFurnished_Size3 <- Bungalow_PartlyFurnished[Bungalow_PartlyFurnished$Size_Value > size_range_3_min, ]

# Print the filtered data and row counts for Bungalow (Bangsar) - Partly Furnished
cat("Bungalow (Bangsar) - Partly Furnished - Size < 3500:\n")
print(Bungalow_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(Bungalow_PartlyFurnished_Size1), "\n\n")

cat("Bungalow (Bangsar) - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(Bungalow_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(Bungalow_PartlyFurnished_Size2), "\n\n")

cat("Bungalow (Bangsar) - Partly Furnished - Size > 5000:\n")
print(Bungalow_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(Bungalow_PartlyFurnished_Size3), "\n\n")

# Condominium (Corner) - Partly Furnished
Condominium_Corner_Bangsar_PartlyFurnished_Size1 <- Condominium_Corner_Bangsar_PartlyFurnished[Condominium_Corner_Bangsar_PartlyFurnished$Size_Value < size_range_1, ]
Condominium_Corner_Bangsar_PartlyFurnished_Size2 <- Condominium_Corner_Bangsar_PartlyFurnished[Condominium_Corner_Bangsar_PartlyFurnished$Size_Value >= size_range_2_min & Condominium_Corner_Bangsar_PartlyFurnished$Size_Value <= size_range_2_max, ]
Condominium_Corner_Bangsar_PartlyFurnished_Size3 <- Condominium_Corner_Bangsar_PartlyFurnished[Condominium_Corner_Bangsar_PartlyFurnished$Size_Value > size_range_3_min, ]

# Print the filtered data and row counts for Condominium (Corner) - Partly Furnished
cat("Condominium (Corner) - Partly Furnished - Size < 3500:\n")
print(Condominium_Corner_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(Condominium_Corner_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("Condominium (Corner) - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(Condominium_Corner_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(Condominium_Corner_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("Condominium (Corner) - Partly Furnished - Size > 5000:\n")
print(Condominium_Corner_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(Condominium_Corner_Bangsar_PartlyFurnished_Size3), "\n\n")

# Bungalow (Intermediate) - Partly Furnished
Bungalow_Intermediate_Bangsar_PartlyFurnished_Size1 <- Bungalow_Intermediate_Bangsar_PartlyFurnished[Bungalow_Intermediate_Bangsar_PartlyFurnished$Size_Value < size_range_1, ]
Bungalow_Intermediate_Bangsar_PartlyFurnished_Size2 <- Bungalow_Intermediate_Bangsar_PartlyFurnished[Bungalow_Intermediate_Bangsar_PartlyFurnished$Size_Value >= size_range_2_min & Bungalow_Intermediate_Bangsar_PartlyFurnished$Size_Value <= size_range_2_max, ]
Bungalow_Intermediate_Bangsar_PartlyFurnished_Size3 <- Bungalow_Intermediate_Bangsar_PartlyFurnished[Bungalow_Intermediate_Bangsar_PartlyFurnished$Size_Value > size_range_3_min, ]

# Print the filtered data and row counts for Bungalow (Intermediate) - Partly Furnished
cat("Bungalow (Intermediate) - Partly Furnished - Size < 3500:\n")
print(Bungalow_Intermediate_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(Bungalow_Intermediate_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("Bungalow (Intermediate) - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(Bungalow_Intermediate_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(Bungalow_Intermediate_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("Bungalow (Intermediate) - Partly Furnished - Size > 5000:\n")
print(Bungalow_Intermediate_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(Bungalow_Intermediate_Bangsar_PartlyFurnished_Size3), "\n\n")

# Condominium - Partly Furnished
Condominium_Bangsar_PartlyFurnished_Size1 <- Condominium_Bangsar_PartlyFurnished[Condominium_Bangsar_PartlyFurnished$Size_Value < size_range_1, ]
Condominium_Bangsar_PartlyFurnished_Size2 <- Condominium_Bangsar_PartlyFurnished[Condominium_Bangsar_PartlyFurnished$Size_Value >= size_range_2_min & Condominium_Bangsar_PartlyFurnished$Size_Value <= size_range_2_max, ]
Condominium_Bangsar_PartlyFurnished_Size3 <- Condominium_Bangsar_PartlyFurnished[Condominium_Bangsar_PartlyFurnished$Size_Value > size_range_3_min, ]

# Print the filtered data and row counts for Condominium - Partly Furnished
cat("Condominium - Partly Furnished - Size < 3500:\n")
print(Condominium_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(Condominium_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("Condominium - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(Condominium_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(Condominium_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("Condominium - Partly Furnished - Size > 5000:\n")
print(Condominium_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(Condominium_Bangsar_PartlyFurnished_Size3), "\n\n")

# Semi-Detached House - Partly Furnished
Semi_Detached_House_Bangsar_PartlyFurnished_Size1 <- Semi_Detached_House_Bangsar_PartlyFurnished[Semi_Detached_House_Bangsar_PartlyFurnished$Size_Value < size_range_1, ]
Semi_Detached_House_Bangsar_PartlyFurnished_Size2 <- Semi_Detached_House_Bangsar_PartlyFurnished[Semi_Detached_House_Bangsar_PartlyFurnished$Size_Value >= size_range_2_min & Semi_Detached_House_Bangsar_PartlyFurnished$Size_Value <= size_range_2_max, ]
Semi_Detached_House_Bangsar_PartlyFurnished_Size3 <- Semi_Detached_House_Bangsar_PartlyFurnished[Semi_Detached_House_Bangsar_PartlyFurnished$Size_Value > size_range_3_min, ]

# Print the filtered data and row counts for Semi-Detached House - Partly Furnished
cat("Semi-Detached House - Partly Furnished - Size < 3500:\n")
print(Semi_Detached_House_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(Semi_Detached_House_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("Semi-Detached House - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(Semi_Detached_House_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(Semi_Detached_House_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("Semi-Detached House - Partly Furnished - Size > 5000:\n")
print(Semi_Detached_House_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(Semi_Detached_House_Bangsar_PartlyFurnished_Size3), "\n\n")

# Two-Story Terrace Link House (End Lot) - Partly Furnished
TwoStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished_Size1 <- TwoStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished[TwoStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished$Size_Value < size_range_1, ]
TwoStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished_Size2 <- TwoStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished[TwoStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished$Size_Value >= size_range_2_min & TwoStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished$Size_Value <= size_range_2_max, ]
TwoStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished_Size3 <- TwoStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished[TwoStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished$Size_Value > size_range_3_min, ]

# Print the filtered data and row counts for Two-Story Terrace Link House (End Lot) - Partly Furnished
cat("Two-Story Terrace Link House (End Lot) - Partly Furnished - Size < 3500:\n")
print(TwoStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(TwoStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("Two-Story Terrace Link House (End Lot) - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(TwoStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(TwoStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("Two-Story Terrace Link House (End Lot) - Partly Furnished - Size > 5000:\n")
print(TwoStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(TwoStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished_Size3), "\n\n")

# Two-Story Terrace Link House (Intermediate) - Partly Furnished
TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size1 <- TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished[TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished$Size_Value < size_range_1, ]
TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size2 <- TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished[TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished$Size_Value >= size_range_2_min & TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished$Size_Value <= size_range_2_max, ]
TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size3 <- TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished[TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished$Size_Value > size_range_3_min, ]

# Print the filtered data and row counts for Two-Story Terrace Link House (Intermediate) - Partly Furnished
cat("Two-Story Terrace Link House (Intermediate) - Partly Furnished - Size < 3500:\n")
print(TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("Two-Story Terrace Link House (Intermediate) - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("Two-Story Terrace Link House (Intermediate) - Partly Furnished - Size > 5000:\n")
print(TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size3), "\n\n")

# Two-Story Terrace Link House - Partly Furnished
TwoStory_Terrace_LinkHouse_Bangsar_PartlyFurnished_Size1 <- TwoStory_Terrace_LinkHouse_Bangsar_PartlyFurnished[TwoStory_Terrace_LinkHouse_Bangsar_PartlyFurnished$Size_Value < size_range_1, ]
TwoStory_Terrace_LinkHouse_Bangsar_PartlyFurnished_Size2 <- TwoStory_Terrace_LinkHouse_Bangsar_PartlyFurnished[TwoStory_Terrace_LinkHouse_Bangsar_PartlyFurnished$Size_Value >= size_range_2_min & TwoStory_Terrace_LinkHouse_Bangsar_PartlyFurnished$Size_Value <= size_range_2_max, ]
TwoStory_Terrace_LinkHouse_Bangsar_PartlyFurnished_Size3 <- TwoStory_Terrace_LinkHouse_Bangsar_PartlyFurnished[TwoStory_Terrace_LinkHouse_Bangsar_PartlyFurnished$Size_Value > size_range_3_min, ]

# Print the filtered data and row counts for Two-Story Terrace Link House - Partly Furnished
cat("Two-Story Terrace Link House - Partly Furnished - Size < 3500:\n")
print(TwoStory_Terrace_LinkHouse_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(TwoStory_Terrace_LinkHouse_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("Two-Story Terrace Link House - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(TwoStory_Terrace_LinkHouse_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(TwoStory_Terrace_LinkHouse_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("Two-Story Terrace Link House - Partly Furnished - Size > 5000:\n")
print(TwoStory_Terrace_LinkHouse_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(TwoStory_Terrace_LinkHouse_Bangsar_PartlyFurnished_Size3), "\n\n")

# Three and a Half Story Terrace Link House (Intermediate) - Partly Furnished
ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size1 <- ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished[ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished$Size_Value < size_range_1, ]
ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size2 <- ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished[ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished$Size_Value >= size_range_2_min & ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished$Size_Value <= size_range_2_max, ]
ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size3 <- ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished[ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished$Size_Value > size_range_3_min, ]

# Print the filtered data and row counts for Three and a Half Story Terrace Link House (Intermediate) - Partly Furnished
cat("Three and a Half Story Terrace Link House (Intermediate) - Partly Furnished - Size < 3500:\n")
print(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("Three and a Half Story Terrace Link House (Intermediate) - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("Three and a Half Story Terrace Link House (Intermediate) - Partly Furnished - Size > 5000:\n")
print(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size3), "\n\n")

# Two-Story Terrace Link House (Corner) - Partly Furnished
TwoStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size1 <- TwoStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished[TwoStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished$Size_Value < size_range_1, ]
TwoStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size2 <- TwoStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished[TwoStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished$Size_Value >= size_range_2_min & TwoStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished$Size_Value <= size_range_2_max, ]
TwoStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size3 <- TwoStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished[TwoStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished$Size_Value > size_range_3_min, ]

# Print the filtered data and row counts for Two-Story Terrace Link House (Corner) - Partly Furnished
cat("Two-Story Terrace Link House (Corner) - Partly Furnished - Size < 3500:\n")
print(TwoStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(TwoStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("Two-Story Terrace Link House (Corner) - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(TwoStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(TwoStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("Two-Story Terrace Link House (Corner) - Partly Furnished - Size > 5000:\n")
print(TwoStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(TwoStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size3), "\n\n")

# Semi-Detached House (Intermediate) - Partly Furnished
Semi_Detached_House_Intermediate_Bangsar_PartlyFurnished_Size1 <- Semi_Detached_House_Intermediate_Bangsar_PartlyFurnished[Semi_Detached_House_Intermediate_Bangsar_PartlyFurnished$Size_Value < size_range_1, ]
Semi_Detached_House_Intermediate_Bangsar_PartlyFurnished_Size2 <- Semi_Detached_House_Intermediate_Bangsar_PartlyFurnished[Semi_Detached_House_Intermediate_Bangsar_PartlyFurnished$Size_Value >= size_range_2_min & Semi_Detached_House_Intermediate_Bangsar_PartlyFurnished$Size_Value <= size_range_2_max, ]
Semi_Detached_House_Intermediate_Bangsar_PartlyFurnished_Size3 <- Semi_Detached_House_Intermediate_Bangsar_PartlyFurnished[Semi_Detached_House_Intermediate_Bangsar_PartlyFurnished$Size_Value > size_range_3_min, ]

# Print the filtered data and row counts for Semi-Detached House (Intermediate) - Partly Furnished
cat("Semi-Detached House (Intermediate) - Partly Furnished - Size < 3500:\n")
print(Semi_Detached_House_Intermediate_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(Semi_Detached_House_Intermediate_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("Semi-Detached House (Intermediate) - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(Semi_Detached_House_Intermediate_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(Semi_Detached_House_Intermediate_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("Semi-Detached House (Intermediate) - Partly Furnished - Size > 5000:\n")
print(Semi_Detached_House_Intermediate_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(Semi_Detached_House_Intermediate_Bangsar_PartlyFurnished_Size3), "\n\n")

# Four-Story Terrace Link House (Corner) - Partly Furnished
FourStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size1 <- FourStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished[FourStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished$Size_Value < size_range_1, ]
FourStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size2 <- FourStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished[FourStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished$Size_Value >= size_range_2_min & FourStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished$Size_Value <= size_range_2_max, ]
FourStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size3 <- FourStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished[FourStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished$Size_Value > size_range_3_min, ]

# Print the filtered data and row counts for Four-Story Terrace Link House (Corner) - Partly Furnished
cat("Four-Story Terrace Link House (Corner) - Partly Furnished - Size < 3500:\n")
print(FourStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(FourStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("Four-Story Terrace Link House (Corner) - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(FourStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(FourStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("Four-Story Terrace Link House (Corner) - Partly Furnished - Size > 5000:\n")
print(FourStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(FourStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size3), "\n\n")

# Condominium (Intermediate) - Partly Furnished
Condominium_Intermediate_Bangsar_PartlyFurnished_Size1 <- Condominium_Intermediate_Bangsar_PartlyFurnished[Condominium_Intermediate_Bangsar_PartlyFurnished$Size_Value < size_range_1, ]
Condominium_Intermediate_Bangsar_PartlyFurnished_Size2 <- Condominium_Intermediate_Bangsar_PartlyFurnished[Condominium_Intermediate_Bangsar_PartlyFurnished$Size_Value >= size_range_2_min & Condominium_Intermediate_Bangsar_PartlyFurnished$Size_Value <= size_range_2_max, ]
Condominium_Intermediate_Bangsar_PartlyFurnished_Size3 <- Condominium_Intermediate_Bangsar_PartlyFurnished[Condominium_Intermediate_Bangsar_PartlyFurnished$Size_Value > size_range_3_min, ]

# Print the filtered data and row counts for Condominium (Intermediate) - Partly Furnished
cat("Condominium (Intermediate) - Partly Furnished - Size < 3500:\n")
print(Condominium_Intermediate_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(Condominium_Intermediate_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("Condominium (Intermediate) - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(Condominium_Intermediate_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(Condominium_Intermediate_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("Condominium (Intermediate) - Partly Furnished - Size > 5000:\n")
print(Condominium_Intermediate_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(Condominium_Intermediate_Bangsar_PartlyFurnished_Size3), "\n\n")

# Three-Story Terrace Link House (Intermediate) - Partly Furnished
ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size1 <- ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished[ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished$Size_Value < size_range_1, ]
ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size2 <- ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished[ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished$Size_Value >= size_range_2_min & ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished$Size_Value <= size_range_2_max, ]
ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size3 <- ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished[ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished$Size_Value > size_range_3_min, ]

# Print the filtered data and row counts for Three-Story Terrace Link House (Intermediate) - Partly Furnished
cat("Three-Story Terrace Link House (Intermediate) - Partly Furnished - Size < 3500:\n")
print(ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("Three-Story Terrace Link House (Intermediate) - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("Three-Story Terrace Link House (Intermediate) - Partly Furnished - Size > 5000:\n")
print(ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(ThreeStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size3), "\n\n")

# Townhouse (End Lot) - Partly Furnished
Townhouse_EndLot_Bangsar_PartlyFurnished_Size1 <- Townhouse_EndLot_Bangsar_PartlyFurnished[Townhouse_EndLot_Bangsar_PartlyFurnished$Size_Value < size_range_1, ]
Townhouse_EndLot_Bangsar_PartlyFurnished_Size2 <- Townhouse_EndLot_Bangsar_PartlyFurnished[Townhouse_EndLot_Bangsar_PartlyFurnished$Size_Value >= size_range_2_min & Townhouse_EndLot_Bangsar_PartlyFurnished$Size_Value <= size_range_2_max, ]
Townhouse_EndLot_Bangsar_PartlyFurnished_Size3 <- Townhouse_EndLot_Bangsar_PartlyFurnished[Townhouse_EndLot_Bangsar_PartlyFurnished$Size_Value > size_range_3_min, ]

# Print the filtered data and row counts for Townhouse (End Lot) - Partly Furnished
cat("Townhouse (End Lot) - Partly Furnished - Size < 3500:\n")
print(Townhouse_EndLot_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(Townhouse_EndLot_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("Townhouse (End Lot) - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(Townhouse_EndLot_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(Townhouse_EndLot_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("Townhouse (End Lot) - Partly Furnished - Size > 5000:\n")
print(Townhouse_EndLot_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(Townhouse_EndLot_Bangsar_PartlyFurnished_Size3), "\n\n")

# Semi-Detached House (Triplex) - Partly Furnished
Semi_Detached_House_Triplex_Bangsar_PartlyFurnished_Size1 <- Semi_Detached_House_Triplex_Bangsar_PartlyFurnished[Semi_Detached_House_Triplex_Bangsar_PartlyFurnished$Size_Value < size_range_1, ]
Semi_Detached_House_Triplex_Bangsar_PartlyFurnished_Size2 <- Semi_Detached_House_Triplex_Bangsar_PartlyFurnished[Semi_Detached_House_Triplex_Bangsar_PartlyFurnished$Size_Value >= size_range_2_min & Semi_Detached_House_Triplex_Bangsar_PartlyFurnished$Size_Value <= size_range_2_max, ]
Semi_Detached_House_Triplex_Bangsar_PartlyFurnished_Size3 <- Semi_Detached_House_Triplex_Bangsar_PartlyFurnished[Semi_Detached_House_Triplex_Bangsar_PartlyFurnished$Size_Value > size_range_3_min, ]

# Print the filtered data and row counts for Semi-Detached House (Triplex) - Partly Furnished
cat("Semi-Detached House (Triplex) - Partly Furnished - Size < 3500:\n")
print(Semi_Detached_House_Triplex_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(Semi_Detached_House_Triplex_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("Semi-Detached House (Triplex) - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(Semi_Detached_House_Triplex_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(Semi_Detached_House_Triplex_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("Semi-Detached House (Triplex) - Partly Furnished - Size > 5000:\n")
print(Semi_Detached_House_Triplex_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(Semi_Detached_House_Triplex_Bangsar_PartlyFurnished_Size3), "\n\n")

# Condominium (Duplex) - Partly Furnished
Condominium_Duplex_Bangsar_PartlyFurnished_Size1 <- Condominium_Duplex_Bangsar_PartlyFurnished[Condominium_Duplex_Bangsar_PartlyFurnished$Size_Value < size_range_1, ]
Condominium_Duplex_Bangsar_PartlyFurnished_Size2 <- Condominium_Duplex_Bangsar_PartlyFurnished[Condominium_Duplex_Bangsar_PartlyFurnished$Size_Value >= size_range_2_min & Condominium_Duplex_Bangsar_PartlyFurnished$Size_Value <= size_range_2_max, ]
Condominium_Duplex_Bangsar_PartlyFurnished_Size3 <- Condominium_Duplex_Bangsar_PartlyFurnished[Condominium_Duplex_Bangsar_PartlyFurnished$Size_Value > size_range_3_min, ]

# Print the filtered data and row counts for Condominium (Duplex) - Partly Furnished
cat("Condominium (Duplex) - Partly Furnished - Size < 3500:\n")
print(Condominium_Duplex_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(Condominium_Duplex_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("Condominium (Duplex) - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(Condominium_Duplex_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(Condominium_Duplex_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("Condominium (Duplex) - Partly Furnished - Size > 5000:\n")
print(Condominium_Duplex_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(Condominium_Duplex_Bangsar_PartlyFurnished_Size3), "\n\n")

# Bungalow (End Lot) - Partly Furnished
Bungalow_EndLot_Bangsar_PartlyFurnished_Size1 <- Bungalow_EndLot_Bangsar_PartlyFurnished[Bungalow_EndLot_Bangsar_PartlyFurnished$Size_Value < size_range_1, ]
Bungalow_EndLot_Bangsar_PartlyFurnished_Size2 <- Bungalow_EndLot_Bangsar_PartlyFurnished[Bungalow_EndLot_Bangsar_PartlyFurnished$Size_Value >= size_range_2_min & Bungalow_EndLot_Bangsar_PartlyFurnished$Size_Value <= size_range_2_max, ]
Bungalow_EndLot_Bangsar_PartlyFurnished_Size3 <- Bungalow_EndLot_Bangsar_PartlyFurnished[Bungalow_EndLot_Bangsar_PartlyFurnished$Size_Value > size_range_3_min, ]

# Print the filtered data and row counts for Bungalow (End Lot) - Partly Furnished
cat("Bungalow (End Lot) - Partly Furnished - Size < 3500:\n")
print(Bungalow_EndLot_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(Bungalow_EndLot_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("Bungalow (End Lot) - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(Bungalow_EndLot_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(Bungalow_EndLot_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("Bungalow (End Lot) - Partly Furnished - Size > 5000:\n")
print(Bungalow_EndLot_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(Bungalow_EndLot_Bangsar_PartlyFurnished_Size3), "\n\n")

# Serviced Residence - Partly Furnished
Serviced_Residence_Bangsar_PartlyFurnished_Size1 <- Serviced_Residence_Bangsar_PartlyFurnished[Serviced_Residence_Bangsar_PartlyFurnished$Size_Value < size_range_1, ]
Serviced_Residence_Bangsar_PartlyFurnished_Size2 <- Serviced_Residence_Bangsar_PartlyFurnished[Serviced_Residence_Bangsar_PartlyFurnished$Size_Value >= size_range_2_min & Serviced_Residence_Bangsar_PartlyFurnished$Size_Value <= size_range_2_max, ]
Serviced_Residence_Bangsar_PartlyFurnished_Size3 <- Serviced_Residence_Bangsar_PartlyFurnished[Serviced_Residence_Bangsar_PartlyFurnished$Size_Value > size_range_3_min, ]

# Print the filtered data and row counts for Serviced Residence - Partly Furnished
cat("Serviced Residence - Partly Furnished - Size < 3500:\n")
print(Serviced_Residence_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(Serviced_Residence_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("Serviced Residence - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(Serviced_Residence_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(Serviced_Residence_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("Serviced Residence - Partly Furnished - Size > 5000:\n")
print(Serviced_Residence_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(Serviced_Residence_Bangsar_PartlyFurnished_Size3), "\n\n")

# TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar - Partly Furnished
TwoPointFiveStory_Terrace_LinkHouse_EndLot_PartlyFurnished_Size1 <- TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished[TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished$Size_Value < size_range_1, ]
TwoPointFiveStory_Terrace_LinkHouse_EndLot_PartlyFurnished_Size2 <- TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished[TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished$Size_Value >= size_range_2_min & TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished$Size_Value <= size_range_2_max, ]
TwoPointFiveStory_Terrace_LinkHouse_EndLot_PartlyFurnished_Size3 <- TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished[TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished$Size_Value > size_range_3_min, ]

# Print the filtered data and row counts for TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar - Partly Furnished
cat("TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar - Partly Furnished - Size < 3500:\n")
print(TwoPointFiveStory_Terrace_LinkHouse_EndLot_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(TwoPointFiveStory_Terrace_LinkHouse_EndLot_PartlyFurnished_Size1), "\n\n")

cat("TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(TwoPointFiveStory_Terrace_LinkHouse_EndLot_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(TwoPointFiveStory_Terrace_LinkHouse_EndLot_PartlyFurnished_Size2), "\n\n")

cat("TwoPointFiveStory_Terrace_LinkHouse_EndLot_Bangsar - Partly Furnished - Size > 5000:\n")
print(TwoPointFiveStory_Terrace_LinkHouse_EndLot_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(TwoPointFiveStory_Terrace_LinkHouse_EndLot_PartlyFurnished_Size3), "\n\n")

# Townhouse_Bangsar - Partly Furnished
Townhouse_PartlyFurnished_Size1 <- Townhouse_Bangsar_PartlyFurnished[Townhouse_Bangsar_PartlyFurnished$Size_Value < size_range_1, ]
Townhouse_PartlyFurnished_Size2 <- Townhouse_Bangsar_PartlyFurnished[Townhouse_Bangsar_PartlyFurnished$Size_Value >= size_range_2_min & Townhouse_Bangsar_PartlyFurnished$Size_Value <= size_range_2_max, ]
Townhouse_PartlyFurnished_Size3 <- Townhouse_Bangsar_PartlyFurnished[Townhouse_Bangsar_PartlyFurnished$Size_Value > size_range_3_min, ]

# Print the filtered data and row counts for Townhouse_Bangsar - Partly Furnished
cat("Townhouse_Bangsar - Partly Furnished - Size < 3500:\n")
print(Townhouse_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(Townhouse_PartlyFurnished_Size1), "\n\n")

cat("Townhouse_Bangsar - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(Townhouse_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(Townhouse_PartlyFurnished_Size2), "\n\n")

cat("Townhouse_Bangsar - Partly Furnished - Size > 5000:\n")
print(Townhouse_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(Townhouse_PartlyFurnished_Size3), "\n\n")

# Condominium_EndLot_Bangsar - Partly Furnished
Condominium_EndLot_PartlyFurnished_Size1 <- Condominium_EndLot_Bangsar_PartlyFurnished[Condominium_EndLot_Bangsar_PartlyFurnished$Size_Value < size_range_1, ]
Condominium_EndLot_PartlyFurnished_Size2 <- Condominium_EndLot_Bangsar_PartlyFurnished[Condominium_EndLot_Bangsar_PartlyFurnished$Size_Value >= size_range_2_min & Condominium_EndLot_Bangsar_PartlyFurnished$Size_Value <= size_range_2_max, ]
Condominium_EndLot_PartlyFurnished_Size3 <- Condominium_EndLot_Bangsar_PartlyFurnished[Condominium_EndLot_Bangsar_PartlyFurnished$Size_Value > size_range_3_min, ]

# Print the filtered data and row counts for Condominium_EndLot_Bangsar - Partly Furnished
cat("Condominium_EndLot_Bangsar - Partly Furnished - Size < 3500:\n")
print(Condominium_EndLot_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(Condominium_EndLot_PartlyFurnished_Size1), "\n\n")

cat("Condominium_EndLot_Bangsar - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(Condominium_EndLot_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(Condominium_EndLot_PartlyFurnished_Size2), "\n\n")

cat("Condominium_EndLot_Bangsar - Partly Furnished - Size > 5000:\n")
print(Condominium_EndLot_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(Condominium_EndLot_PartlyFurnished_Size3), "\n\n")

# Print the filtered data and row counts for ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar - Partly Furnished
cat("ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar - Partly Furnished - Size < 3500:\n")
print(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar - Partly Furnished - Size > 5000:\n")
print(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(ThreePointFiveStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size3), "\n\n")

# Residential_Land_Bangsar - Partly Furnished
Residential_Land_Bangsar_PartlyFurnished_Size1 <- Residential_Land_Bangsar[Residential_Land_Bangsar$Size_Value < size_range_1 & Residential_Land_Bangsar$Furnishing_Status == "Partly Furnished", ]
Residential_Land_Bangsar_PartlyFurnished_Size2 <- Residential_Land_Bangsar[Residential_Land_Bangsar$Size_Value >= size_range_2_min & Residential_Land_Bangsar$Size_Value <= size_range_2_max & Residential_Land_Bangsar$Furnishing_Status == "Partly Furnished", ]
Residential_Land_Bangsar_PartlyFurnished_Size3 <- Residential_Land_Bangsar[Residential_Land_Bangsar$Size_Value > size_range_3_min & Residential_Land_Bangsar$Furnishing_Status == "Partly Furnished", ]

# Print the filtered data and row counts for Residential_Land_Bangsar - Partly Furnished
cat("Residential_Land_Bangsar - Partly Furnished - Size < 3500:\n")
print(Residential_Land_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(Residential_Land_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("Residential_Land_Bangsar - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(Residential_Land_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(Residential_Land_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("Residential_Land_Bangsar - Partly Furnished - Size > 5000:\n")
print(Residential_Land_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(Residential_Land_Bangsar_PartlyFurnished_Size3), "\n\n")

# Condominium_Triplex_Bangsar - Partly Furnished
Condominium_Triplex_Bangsar_PartlyFurnished_Size1 <- Condominium_Triplex_Bangsar[Condominium_Triplex_Bangsar$Size_Value < size_range_1 & Condominium_Triplex_Bangsar$Furnishing_Status == "Partly Furnished", ]
Condominium_Triplex_Bangsar_PartlyFurnished_Size2 <- Condominium_Triplex_Bangsar[Condominium_Triplex_Bangsar$Size_Value >= size_range_2_min & Condominium_Triplex_Bangsar$Size_Value <= size_range_2_max & Condominium_Triplex_Bangsar$Furnishing_Status == "Partly Furnished", ]
Condominium_Triplex_Bangsar_PartlyFurnished_Size3 <- Condominium_Triplex_Bangsar[Condominium_Triplex_Bangsar$Size_Value > size_range_3_min & Condominium_Triplex_Bangsar$Furnishing_Status == "Partly Furnished", ]

# Print the filtered data and row counts for Condominium_Triplex_Bangsar - Partly Furnished
cat("Condominium_Triplex_Bangsar - Partly Furnished - Size < 3500:\n")
print(Condominium_Triplex_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(Condominium_Triplex_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("Condominium_Triplex_Bangsar - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(Condominium_Triplex_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(Condominium_Triplex_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("Condominium_Triplex_Bangsar - Partly Furnished - Size > 5000:\n")
print(Condominium_Triplex_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(Condominium_Triplex_Bangsar_PartlyFurnished_Size3), "\n\n")

# FourStory_Terrace_LinkHouse_Bangsar - Partly Furnished
FourStory_Terrace_LinkHouse_Bangsar_PartlyFurnished_Size1 <- FourStory_Terrace_LinkHouse_Bangsar[FourStory_Terrace_LinkHouse_Bangsar$Size_Value < size_range_1 & FourStory_Terrace_LinkHouse_Bangsar$Furnishing_Status == "Partly Furnished", ]
FourStory_Terrace_LinkHouse_Bangsar_PartlyFurnished_Size2 <- FourStory_Terrace_LinkHouse_Bangsar[FourStory_Terrace_LinkHouse_Bangsar$Size_Value >= size_range_2_min & FourStory_Terrace_LinkHouse_Bangsar$Size_Value <= size_range_2_max & FourStory_Terrace_LinkHouse_Bangsar$Furnishing_Status == "Partly Furnished", ]
FourStory_Terrace_LinkHouse_Bangsar_PartlyFurnished_Size3 <- FourStory_Terrace_LinkHouse_Bangsar[FourStory_Terrace_LinkHouse_Bangsar$Size_Value > size_range_3_min & FourStory_Terrace_LinkHouse_Bangsar$Furnishing_Status == "Partly Furnished", ]

# Print the filtered data and row counts for FourStory_Terrace_LinkHouse_Bangsar - Partly Furnished
cat("FourStory_Terrace_LinkHouse_Bangsar - Partly Furnished - Size < 3500:\n")
print(FourStory_Terrace_LinkHouse_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(FourStory_Terrace_LinkHouse_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("FourStory_Terrace_LinkHouse_Bangsar - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(FourStory_Terrace_LinkHouse_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(FourStory_Terrace_LinkHouse_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("FourStory_Terrace_LinkHouse_Bangsar - Partly Furnished - Size > 5000:\n")
print(FourStory_Terrace_LinkHouse_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(FourStory_Terrace_LinkHouse_Bangsar_PartlyFurnished_Size3), "\n\n")

# Condominium_Penthouse_Bangsar - Partly Furnished
Condominium_Penthouse_Bangsar_PartlyFurnished_Size1 <- Condominium_Penthouse_Bangsar[Condominium_Penthouse_Bangsar$Size_Value < size_range_1 & Condominium_Penthouse_Bangsar$Furnishing_Status == "Partly Furnished", ]
Condominium_Penthouse_Bangsar_PartlyFurnished_Size2 <- Condominium_Penthouse_Bangsar[Condominium_Penthouse_Bangsar$Size_Value >= size_range_2_min & Condominium_Penthouse_Bangsar$Size_Value <= size_range_2_max & Condominium_Penthouse_Bangsar$Furnishing_Status == "Partly Furnished", ]
Condominium_Penthouse_Bangsar_PartlyFurnished_Size3 <- Condominium_Penthouse_Bangsar[Condominium_Penthouse_Bangsar$Size_Value > size_range_3_min & Condominium_Penthouse_Bangsar$Furnishing_Status == "Partly Furnished", ]

# Print the filtered data and row counts for Condominium_Penthouse_Bangsar - Partly Furnished
cat("Condominium_Penthouse_Bangsar - Partly Furnished - Size < 3500:\n")
print(Condominium_Penthouse_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(Condominium_Penthouse_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("Condominium_Penthouse_Bangsar - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(Condominium_Penthouse_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(Condominium_Penthouse_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("Condominium_Penthouse_Bangsar - Partly Furnished - Size > 5000:\n")
print(Condominium_Penthouse_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(Condominium_Penthouse_Bangsar_PartlyFurnished_Size3), "\n\n")

# ThreeStory_Terrace_LinkHouse_EndLot_Bangsar - Partly Furnished
ThreeStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished_Size1 <- ThreeStory_Terrace_LinkHouse_EndLot_Bangsar[ThreeStory_Terrace_LinkHouse_EndLot_Bangsar$Size_Value < size_range_1 & ThreeStory_Terrace_LinkHouse_EndLot_Bangsar$Furnishing_Status == "Partly Furnished", ]
ThreeStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished_Size2 <- ThreeStory_Terrace_LinkHouse_EndLot_Bangsar[ThreeStory_Terrace_LinkHouse_EndLot_Bangsar$Size_Value >= size_range_2_min & ThreeStory_Terrace_LinkHouse_EndLot_Bangsar$Size_Value <= size_range_2_max & ThreeStory_Terrace_LinkHouse_EndLot_Bangsar$Furnishing_Status == "Partly Furnished", ]
ThreeStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished_Size3 <- ThreeStory_Terrace_LinkHouse_EndLot_Bangsar[ThreeStory_Terrace_LinkHouse_EndLot_Bangsar$Size_Value > size_range_3_min & ThreeStory_Terrace_LinkHouse_EndLot_Bangsar$Furnishing_Status == "Partly Furnished", ]

# Print the filtered data and row counts for ThreeStory_Terrace_LinkHouse_EndLot_Bangsar - Partly Furnished
cat("ThreeStory_Terrace_LinkHouse_EndLot_Bangsar - Partly Furnished - Size < 3500:\n")
print(ThreeStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(ThreeStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("ThreeStory_Terrace_LinkHouse_EndLot_Bangsar - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(ThreeStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(ThreeStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("ThreeStory_Terrace_LinkHouse_EndLot_Bangsar - Partly Furnished - Size > 5000:\n")
print(ThreeStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(ThreeStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished_Size3), "\n\n")

# OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar - Partly Furnished
OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size1 <- OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar[OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar$Size_Value < size_range_1 & OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar$Furnishing_Status == "Partly Furnished", ]
OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size2 <- OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar[OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar$Size_Value >= size_range_2_min & OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar$Size_Value <= size_range_2_max & OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar$Furnishing_Status == "Partly Furnished", ]
OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size3 <- OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar[OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar$Size_Value > size_range_3_min & OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar$Furnishing_Status == "Partly Furnished", ]

# Print the filtered data and row counts for OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar - Partly Furnished
cat("OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar - Partly Furnished - Size < 3500:\n")
print(OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size1)
cat("Number of Rows:", nrow(OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size1), "\n\n")

cat("OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar - Partly Furnished - Size >= 3500 & <= 5000:\n")
print(OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size2)
cat("Number of Rows:", nrow(OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size2), "\n\n")

cat("OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar - Partly Furnished - Size > 5000:\n")
print(OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size3)
cat("Number of Rows:", nrow(OnePointFiveStory_Terrace_LinkHouse_Corner_Bangsar_PartlyFurnished_Size3), "\n\n")

# Graph for Analysis 4
# Combine all the filtered data frames into a single data frame


all_filtered_data <- rbind(
  Bungalow_Corner_Bangsar_PartlyFurnished_Size1,
  Bungalow_Corner_Bangsar_PartlyFurnished_Size2,
  Bungalow_Corner_Bangsar_PartlyFurnished_Size3,
  Bungalow_PartlyFurnished_Size1,
  Bungalow_PartlyFurnished_Size2,
  Bungalow_PartlyFurnished_Size3,
  Condominium_Corner_Bangsar_PartlyFurnished_Size1,
  Condominium_Corner_Bangsar_PartlyFurnished_Size2,
  Condominium_Corner_Bangsar_PartlyFurnished_Size3,
  Bungalow_Intermediate_Bangsar_PartlyFurnished_Size1,
  Bungalow_Intermediate_Bangsar_PartlyFurnished_Size2,
  Bungalow_Intermediate_Bangsar_PartlyFurnished_Size3,
  Semi_Detached_House_Bangsar_PartlyFurnished_Size1,
  Semi_Detached_House_Bangsar_PartlyFurnished_Size2,
  Semi_Detached_House_Bangsar_PartlyFurnished_Size3,
  TwoStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished_Size1,
  TwoStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished_Size2,
  TwoStory_Terrace_LinkHouse_EndLot_Bangsar_PartlyFurnished_Size3,
  TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size1,
  TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size2,
  TwoStory_Terrace_LinkHouse_Intermediate_Bangsar_PartlyFurnished_Size3,
  TwoStory_Terrace_LinkHouse_Bangsar_PartlyFurnished_Size1,
  TwoStory_Terrace_LinkHouse_Bangsar_PartlyFurnished_Size2,
  TwoStory_Terrace_LinkHouse_Bangsar_PartlyFurnished_Size3
)

# Install and load necessary libraries
install.packages("ggplot2")
library(ggplot2)

# Create a lollipop chart
ggplot(all_filtered_data, aes(x = Property.Type, y = Size_Value, color = Furnishing)) +
  geom_segment(aes(x = Property.Type, xend = Property.Type, y = 0, yend = Size_Value), size = 1) +
  geom_point(size = 3) +
  labs(title = "Property Types in Bangsar by Furnishing Status and Size Range",
       x = "Property Type",
       y = "Size Value",
       color = "Furnishing Status") +
  theme_minimal()



# Analysis 5: Property Analysis Based on Price

property_types <- c(
  "Bungalow (Corner)", "Bungalow", "Condominium (Corner)", "Bungalow (Intermediate)", 
  "Condominium", "Semi-detached House", "2-sty Terrace/Link House (EndLot)", 
  "2-sty Terrace/Link House (Intermediate)", "2-sty Terrace/Link House", 
  "3.5-sty Terrace/Link House (Intermediate)", "2-sty Terrace/Link House (Corner)", 
  "Semi-detached House (Intermediate)", "4-sty Terrace/Link House (Corner)", 
  "Condominium (Intermediate)", "3-sty Terrace/Link House (Intermediate)", 
  "Townhouse (EndLot)", "Semi-detached House (Triplex)", "Condominium (Duplex)", 
  "Bungalow (EndLot)", "Serviced Residence", "2.5-sty Terrace/Link House (EndLot)", 
  "Townhouse", "Condominium (EndLot)", "Condominium (Intermediate)", 
  "3.5-sty Terrace/Link House", "Residential Land", "Condominium (Triplex)", 
  "4-sty Terrace/Link House", "Condominium (Penthouse)", "3-sty Terrace/Link House (EndLot)", 
  "1.5-sty Terrace/Link House (Corner)"
)


#partly furnished >= 6million

partly_furnished_properties <- KLpropdata[
  KLpropdata$Location == "Bangsar, Kuala Lumpur" & 
    KLpropdata$Price >= 6000000 & 
    KLpropdata$Furnishing == "Partly Furnished", ]
# View the selected partially furnished properties
print(partly_furnished_properties)
nrow(partly_furnished_properties)

#partly furnished < 6million

partly_furnished_properties <- KLpropdata[
  KLpropdata$Location == "Bangsar, Kuala Lumpur" & 
    KLpropdata$Price < 6000000 & 
    KLpropdata$Furnishing == "Partly Furnished", ]
# View the selected partially furnished properties
print(partly_furnished_properties)
nrow(partly_furnished_properties)


# Remove duplicates if there is any
property_types <- unique(property_types)
count <- 0
for (property_type in property_types) {
  output <- KLpropdata[
    KLpropdata$Location == "Bangsar, Kuala Lumpur" & 
      KLpropdata$Size_Value > 5000 & 
      KLpropdata$Price >= 6000000 & 
      KLpropdata$Property.Type == property_type & 
      KLpropdata$Furnishing == "Partly Furnished", 
  ]
  count <- count + nrow(output)
  
  cat(property_type, "\n")
  print(output)
  cat("Number of properties:", nrow(output), "\n\n")
}

cat("Total number of properties:", count, "\n")


# Graph for Analysis 5 

# Load the ggplot2 library
library(ggplot2)

# Create a bar plot
ggplot(partly_furnished_properties, aes(x = Property.Type, fill = Property.Type)) +
  geom_bar() +
  labs(title = "Property Types in Bangsar with Price >= 6 million and Partly Furnished",
       x = "Property Type",
       y = "Count") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # Rotate x-axis labels for better visibility




