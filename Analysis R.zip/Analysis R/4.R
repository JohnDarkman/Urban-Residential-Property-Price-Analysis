#import default cleaned data
KLpropdatadefault <- read.csv("C:\\Users\\markr\\Downloads\\cleaned_data_default.csv", header = TRUE)

#View table
View(KLpropdatadefault)
#-----------------------------------------------------------------------------------------------------------

#Analysis 1: To analyse the Number of Property based on Price Categories for the entire dataset

#Select properties with price less than 6 million for the entire dataset
less_than_6mil_properties_entire_dataset <- KLpropdatadefault[KLpropdatadefault$Price < 6000000, ]

# View the selected properties
print(less_than_6mil_properties_entire_dataset)
nrow(less_than_6mil_properties_entire_dataset)
# Output: 25464


#Select properties with price greater than or equal to 6 million for the entire dataset
more_than_6mil_properties_entire_dataset <- KLpropdatadefault[KLpropdatadefault$Price >= 6000000, ]

# View the selected properties
print(more_than_6mil_properties_entire_dataset)
nrow(more_than_6mil_properties_entire_dataset)
# Output: 1075


# Load the ggplot2 library
library(ggplot2)

# Create a data frame with property categories and counts
property_counts <- data.frame(
  Category = c("Less than 6 million", "Greater than or equal to 6 million"),
  Count = c(nrow(less_than_6mil_properties_entire_dataset), nrow(more_than_6mil_properties_entire_dataset))
)

# Set a maximum limit for the y-axis
y_limit <- 30000

# Define custom colors
custom_colors <- c("#FF5733", "#33FF57")  

# Create a bar chart with count values displayed on top
ggplot(property_counts, aes(x = Category, y = Count, fill = Category)) +
  geom_bar(stat = "identity", position = "dodge", alpha = 0.7) +
  geom_text(aes(label = Count), vjust = -0.5, position = position_dodge(width = 0.9), size = 3) +
  theme_minimal() +
  labs(title = "Number of Properties Based on Price Categories",
       x = "Price Category",
       y = "Number of Properties") +
  scale_fill_manual(values = custom_colors) +
  coord_cartesian(ylim = c(0, y_limit))


#-----------------------------------------------------------------------------------------------------------

#import clean data
KLpropdata <- read.csv("C:\\Users\\markr\\Documents\\cleaned_dataset_final.csv", header = TRUE)

#View table
View(KLpropdata)

#-----------------------------------------------------------------------------------------------------------

#Analysis 2
#.Select properties with price less than 6 million for bangsar
less_than_6mil_properties_entire_dataset <- KLpropdata[KLpropdata$Price < 6000000, ]

# View the selected properties
print(less_than_6mil_properties_entire_dataset)
nrow(less_than_6mil_properties_entire_dataset)
# Output: 244



#.Select properties with price greater than or equal to 6 million for bangsar
more_than_6mil_properties_entire_dataset <- KLpropdata[KLpropdata$Price >= 6000000, ]

# View the selected properties
print(more_than_6mil_properties_entire_dataset)
nrow(more_than_6mil_properties_entire_dataset)
# Output: 277


library(ggplot2)

# Create a new variable for Price group
KLpropdata$Price_Group <- ifelse(KLpropdata$Price < 6000000, "Below 6M", "6M and Above")

# Plotting
ggplot(KLpropdata, aes(x = factor(Price_Group), fill = factor(Price_Group))) +
  geom_bar(stat = "count", show.legend = FALSE) +
  geom_text(stat = "count", aes(label = after_stat(count)), vjust = -0.5) +
  scale_fill_manual(values = c("Below 6M" = "#377EB8", "6M and Above" = "#E41A1C")) +
  labs(title = "Distribution of Properties in Bangsar by Price",
       x = "Price Group",
       y = "Number of Properties") +
  theme_minimal() +
  theme(axis.title = element_text(size = 14),
        axis.text = element_text(size = 12),
        plot.title = element_text(size = 16, face = "bold"),
        legend.position = "none")
#-----------------------------------------------------------------------------------------------------------

#Analysis 3
#fully furnished >= 6million 
fully_furnished_properties <- KLpropdata[
  KLpropdata$Location == "Bangsar, Kuala Lumpur" & 
    KLpropdata$Price >= 6000000 & 
    KLpropdata$Furnishing == "Fully Furnished", ]

# View the selected fully furnished properties
print(fully_furnished_properties)
nrow(fully_furnished_properties)
#Output: 18

#partly furnished >= 6million
partly_furnished_properties <- KLpropdata[
  KLpropdata$Location == "Bangsar, Kuala Lumpur" & 
    KLpropdata$Price >= 6000000 & 
    KLpropdata$Furnishing == "Partly Furnished", ]

# View the selected partially furnished properties
print(partly_furnished_properties)
nrow(partly_furnished_properties)
#Output=245

#unfurnished >= 6million
unfurnished_properties <- KLpropdata[
  KLpropdata$Location == "Bangsar, Kuala Lumpur" & 
    KLpropdata$Price >= 6000000 & 
    KLpropdata$Furnishing == "Unfurnished", ]
# View the selected unfurnished properties
print(unfurnished_properties)
nrow(unfurnished_properties)
#Output=14

library(ggplot2)

# Define custom colors
custom_colors <- c("#FF5733", "#33FF57", "#3399FF")  
# Filter data for properties priced at 6 million or more
filtered_data <- KLpropdata[
  KLpropdata$Location == "Bangsar, Kuala Lumpur" & 
    KLpropdata$Price >= 6000000, ]

# Plotting
ggplot(filtered_data, aes(x = Furnishing, fill = Furnishing)) +
  geom_bar(stat = "count", position = "dodge", show.legend = FALSE) +
  geom_text(stat = "count", aes(label = after_stat(count)), vjust = -0.5) +
  labs(title = "Distribution of Furnishing Types in Bangsar, Kuala Lumpur (Price >= 6 Million)",
       x = "Furnishing Type",
       y = "Number of Properties") +
  theme_minimal() +
  scale_fill_manual(values = custom_colors) +
  theme(axis.title = element_text(size = 14),
        axis.text = element_text(size = 12),
        plot.title = element_text(size = 16, face = "bold"))


#Analysis 3.1

#fully furnished < 6million 
fully_furnished_properties <- KLpropdata[
  KLpropdata$Location == "Bangsar, Kuala Lumpur" & 
    KLpropdata$Price < 6000000 & 
    KLpropdata$Furnishing == "Fully Furnished", ]
# View the selected fully furnished properties
print(fully_furnished_properties)
nrow(fully_furnished_properties)
#Output: 33

#partly furnished < 6million

partly_furnished_properties <- KLpropdata[
  KLpropdata$Location == "Bangsar, Kuala Lumpur" & 
    KLpropdata$Price < 6000000 & 
    KLpropdata$Furnishing == "Partly Furnished", ]
# View the selected partially furnished properties
print(partly_furnished_properties)
nrow(partly_furnished_properties)
#Output=198

#unfurnished < 6million
unfurnished_properties <- KLpropdata[
  KLpropdata$Location == "Bangsar, Kuala Lumpur" & 
    KLpropdata$Price < 6000000 & 
    KLpropdata$Furnishing == "Unfurnished", ]
# View the selected unfurnished properties
print(unfurnished_properties)
nrow(unfurnished_properties)
#Output=13

library(ggplot2)

# Define custom colors
custom_colors <- c("#FF5733", "#33FF57", "#3399FF")  

# Filter data for properties priced below 6 million
filtered_data_below_6mil <- KLpropdata[
  KLpropdata$Location == "Bangsar, Kuala Lumpur" & 
    KLpropdata$Price < 6000000, ]

# Plotting
ggplot(filtered_data_below_6mil, aes(x = Furnishing, fill = Furnishing)) +
  geom_bar(stat = "count", position = "dodge", show.legend = FALSE) +
  geom_text(stat = "count", aes(label = after_stat(count)), vjust = -0.5) +
  labs(title = "Distribution of Furnishing Types in Bangsar, Kuala Lumpur (Price < 6 Million)",
       x = "Furnishing Type",
       y = "Number of Properties") +
  theme_minimal() +
  scale_fill_manual(values = custom_colors) +
  theme(axis.title = element_text(size = 14),
        axis.text = element_text(size = 12),
        plot.title = element_text(size = 16, face = "bold"))



#-----------------------------------------------------------------------------------------------------------
#Analysis 4
# <3500 more than or equals to 6million partly furnished
# Select properties located in Bangsar, Kuala Lumpur, with size less than 3500 square feet, price >= 6 million, and partly furnished
bangsar_and_size_less_than_3500_and_6mil_partly_furnished <- KLpropdata[
  KLpropdata$Location == "Bangsar, Kuala Lumpur" & 
    KLpropdata$Size_Value < 3500 & 
    KLpropdata$Price >= 6000000 & 
    KLpropdata$Furnishing == "Partly Furnished", ]
# View the selected properties
print(bangsar_and_size_less_than_3500_and_6mil_partly_furnished)
nrow(bangsar_and_size_less_than_3500_and_6mil_partly_furnished)
# Output: 2

#Between 3500 and 5000 >= 6million partly furnished
# Select properties located in Bangsar, Kuala Lumpur, with size between 3500 and 5000 square feet, price >= 6 million, and partly furnished
bangsar_and_size_between_3500_and_5000_and_6mil_partly_furnished <- KLpropdata[
  KLpropdata$Location == "Bangsar, Kuala Lumpur" & 
    KLpropdata$Size_Value >= 3500 & 
    KLpropdata$Size_Value <= 5000 & 
    KLpropdata$Price >= 6000000 & 
    KLpropdata$Furnishing == "Partly Furnished", ]
# View the selected properties
print(bangsar_and_size_between_3500_and_5000_and_6mil_partly_furnished)
nrow(bangsar_and_size_between_3500_and_5000_and_6mil_partly_furnished)
# Output: 94

# >5000 >= 6million partly furnished
# Select properties located in Bangsar, Kuala Lumpur, with size more than 5000 square feet, price >= 6 million, and partly furnished
bangsar_and_size_more_than_5000_and_6mil_partly_furnished <- KLpropdata[
  KLpropdata$Location == "Bangsar, Kuala Lumpur" & 
    KLpropdata$Size_Value > 5000 & 
    KLpropdata$Price >= 6000000 & 
    KLpropdata$Furnishing == "Partly Furnished", ]
# View the selected properties
print(bangsar_and_size_more_than_5000_and_6mil_partly_furnished)
nrow(bangsar_and_size_more_than_5000_and_6mil_partly_furnished)
# Output: 149



# Load the ggplot2 library
library(ggplot2)

# Create a data frame with the information
data <- data.frame(
  Category = c("Size < 3500", "3500-5000", "> 5000"),
  Count = c(2, 94, 149)
)

# Create a vector of unique colors for each category
colors <- c("#FF9999", "#66B2FF", "#99FF99")

# Create the lollipop chart with values displayed
ggplot(data, aes(x = Category, y = Count)) +
  geom_segment(aes(x = Category, xend = Category, y = 0, yend = Count), color = colors) +
  geom_point(color = colors, size = 3) +
  geom_text(aes(label = Count), vjust = -0.5) +  # Display values below each lollipop
  theme_minimal() +
  labs(title = "Number of Properties in Bangsar, KL",
       subtitle = "Based on Size and Price Criteria",
       x = "Size Category",
       y = "Number of Properties")


#-----------------------------------------------------------------------------------------------------------

#Analysis 5

property_types <- c(
  "Bungalow (Corner)", "Bungalow", "Condominium (Corner)", "Bungalow (Intermediate)", 
  "Condominium", "Semi-detached House", "2-sty Terrace/Link House (EndLot)", 
  "2-sty Terrace/Link House (Intermediate)", "2-sty Terrace/Link House", 
  "3.5-sty Terrace/Link House (Intermediate)", "2-sty Terrace/Link House (Corner)", 
  "Semi-detached House (Intermediate)", "4-sty Terrace/Link House (Corner)", 
  "Condominium (Intermediate)", "3-sty Terrace/Link House (Intermediate)", 
  "Townhouse (EndLot)", "Semi-detached House (Triplex)", "Condominium (Duplex)", 
  "Bungalow (EndLot)", "Serviced Residence", "2.5-sty Terrace/Link House (EndLot)", 
  "Townhouse", "Condominium (EndLot)", "Condominium (Intermediate)", 
  "3.5-sty Terrace/Link House", "Residential Land", "Condominium (Triplex)", 
  "4-sty Terrace/Link House", "Condominium (Penthouse)", "3-sty Terrace/Link House (EndLot)", 
  "1.5-sty Terrace/Link House (Corner)"
)

# Remove duplicates if there is any
property_types <- unique(property_types)
count <- 0
for (property_type in property_types) {
  output <- KLpropdata[
    KLpropdata$Location == "Bangsar, Kuala Lumpur" & 
      KLpropdata$Size_Value > 5000 & 
      KLpropdata$Price >= 6000000 & 
      KLpropdata$Property.Type == property_type & 
      KLpropdata$Furnishing == "Partly Furnished", 
  ]
  count <- count + nrow(output)
  
  cat(property_type, "\n")
  print(output)
  cat("Number of properties:", nrow(output), "\n\n")
}

cat("Total number of properties:", count, "\n")


# Load the ggplot2 library
library(ggplot2)

# Define custom colors 
line_color <- "#A93226"  
point_color <- "#1E8449"  
text_color <- "#21618C"  
background_color <- "#D5DBDB"  
grid_color <- "#85929E"  

# Create a data frame with property types and corresponding counts
property_counts <- data.frame(
  PropertyType = property_types,
  Count = numeric(length(property_types))
)

# Loop through each property type and count the properties
for (i in seq_along(property_types)) {
  output <- KLpropdata[
    KLpropdata$Location == "Bangsar, Kuala Lumpur" & 
      KLpropdata$Size_Value > 5000 & 
      KLpropdata$Price >= 6000000 & 
      KLpropdata$Property.Type == property_types[i] & 
      KLpropdata$Furnishing == "Partly Furnished", 
  ]
  property_counts$Count[i] <- nrow(output)
}

# Create the line graph with darker colors
ggplot(property_counts, aes(x = PropertyType, y = Count, group = 1)) +
  geom_line(color = line_color, linetype = "dashed") +
  geom_point(color = point_color, size = 3) +
  geom_text(aes(label = Count), vjust = -0.5, hjust = 0.5, size = 3, color = text_color) +  # Add data labels
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1, face = "bold", color = text_color),
    axis.line = element_line(linewidth = 1, color = text_color, linetype = "solid"),
    panel.grid.major = element_line(color = grid_color, linetype = "dotted"),
    panel.grid.minor = element_blank(),
    plot.background = element_rect(fill = background_color),
    panel.background = element_rect(fill = "white")
  ) +
  labs(title = "Number of Properties in Bangsar, KL",
       subtitle = "Based on Property Type, Size, and Price Criteria",
       x = NULL,
       y = "Number of Properties")

#---------------------------------------------------------------------------------------------------------------------







