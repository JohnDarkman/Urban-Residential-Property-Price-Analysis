#import default cleaned data
KLpropdatadefault <- read.csv("C:\\Users\\KARUENAH DE SILVA\\Downloads\\cleaned_data_default.csv", header = TRUE)

#View table
View(KLpropdatadefault)
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#DATA ANALYSIS
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

#Analysis 1: Size_Value Segmentation In Kuala Lumpur--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

#Segment 1: Size_Value < 3500 in Kuala Lumpur
lesser_than_3500 <- KLpropdatadefault[KLpropdatadefault$Size_Value <3500 , ]
print(lesser_than_3500)
nrow(lesser_than_3500)
#Output = 23273

#Segment 2: 3500 <= Size_Value <= 5000 in Kuala Lumpur
in_between_3500_and_5000 <- KLpropdatadefault[KLpropdatadefault$Size_Value >= 3500  
                                              & KLpropdatadefault$Size_Value <= 5000 , ]
print(in_between_3500_and_5000)
nrow(in_between_3500_and_5000)
#Output = 1608

#Segment 3: Size_Value > 5000 in Kuala Lumpur
more_than_5000 <- KLpropdatadefault[KLpropdatadefault$Size_Value > 5000 , ]
print(more_than_5000)
nrow(more_than_5000)
#Output = 1658


#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#Graph for Analysis 1--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if (!requireNamespace("ggplot2", quietly = TRUE)) {
  install.packages("ggplot2")
}
library(ggplot2)

# Data for bubble chart
bubble_data <- data.frame(
  Segment = c("lesser_than_3500", "in_between_3500_and_5000", "more_than_5000"),
  Count = c(nrow(lesser_than_3500), nrow(in_between_3500_and_5000), nrow(more_than_5000))
)

# Custom colors for different segments
segment_colors <- c("lesser_than_3500" = "darkorange", "in_between_3500_and_5000" = "mediumseagreen", "more_than_5000" = "royalblue")

# Plotting the bubble chart with custom colors
ggplot(bubble_data, aes(x = 1, y = Count, size = Count, fill = Segment)) +
  geom_point(shape = 21, alpha = 0.7, position = position_dodge(width = 0.8)) +
  geom_text(aes(label = Count), vjust = -0.5, size = 4, position = position_dodge(width = 0.8)) +
  scale_size_continuous(range = c(5, 30)) +
  scale_fill_manual(values = segment_colors) +
  labs(title = "Analysis 1: Size Value in Kuala Lumpur",
       x = "Size Value", y = "Number of property") +
  theme_minimal() +
  theme(axis.text.x = element_blank(),
        axis.ticks.x = element_blank(),
        axis.line = element_line(size = 1, color = "black"),  # X-axis line
        axis.text.y = element_text(color = "black"),  # Y-axis text color
        axis.ticks.y = element_line(color = "black"),  # Y-axis tick color
        panel.grid.major = element_line(color = "lightgray", size = 0.5))  # Grid lines

#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
#import clean data
KLpropdata <- read.csv("C:\\Users\\KARUENAH DE SILVA\\Downloads\\cleaned_data.csv", header = TRUE)

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

#Analysis 2: Size_Value Segmentation In Bangsar--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

#Segment 1: Size_Value < 3500 in Bangsar
lesser_than_3500 <- KLpropdata[KLpropdata$Size_Value <3500 , ]
print(lesser_than_3500)
nrow(lesser_than_3500)
#Output = 94

#Segment 2: 3500 <= Size_Value <= 5000 in Bangsar
in_between_3500_and_5000 <- KLpropdata[KLpropdata$Size_Value >= 3500  & KLpropdata$Size_Value <= 5000 , ]
print(in_between_3500_and_5000)
nrow(in_between_3500_and_5000)
#Output = 178

#Segment 3: Size_Value > 5000 in Bangsar
more_than_5000 <- KLpropdata[KLpropdata$Size_Value > 5000 , ]
print(more_than_5000)
nrow(more_than_5000)
#Output = 249

#Graph for Analysis 2--------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if (!requireNamespace("ggplot2", quietly = TRUE)) {
  install.packages("ggplot2")
}
library(ggplot2)

# Data
segments_data <- data.frame(
  Segment = c("Size < 3500", "3500 <= Size <= 5000", "Size > 5000"),
  Count = c(nrow(lesser_than_3500), nrow(in_between_3500_and_5000), nrow(more_than_5000))
)

# Custom colors
custom_colors <- c("#66c2a5", "#fc8d62", "#8da0cb")

# Create lollipop chart with custom colors, actual count numbers, and solid lines for axes
ggplot(segments_data, aes(x = Segment, y = Count)) +
  geom_segment(aes(xend = Segment, yend = 0), color = custom_colors, linewidth = 1.5) +
  geom_point(size = 4, color = custom_colors) +
  geom_text(aes(label = Count), vjust = -0.5, hjust = 0.5) +
  labs(title = "Analysis 2: Size_Value in Bangsar",
       x = "Size Segments",
       y = "Number of properties") +
  scale_color_manual(values = custom_colors) +  # Set custom colors
  theme_minimal() +
  theme(
    axis.line = element_line(color = "black", linewidth = 1),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_blank(),
    panel.background = element_blank()
  )


#----------------------------------------------------------------------------------------------------------------------#
# Analysis 3: Property Analysis Based on Size and Price in Bangsar----------------------------------------------------------------------------------------------------------------------

#lesser_than_3500_and_>=6mil:
lesser_than_3500_and_6mil <- KLpropdata[KLpropdata$Size_Value < 3500 & KLpropdata$Price >= 6000000, ]
print(lesser_than_3500_and_6mil)
nrow(lesser_than_3500_and_6mil)
#Output=2

#in_between_3500_and_5000_and_>=6mil:
in_between_3500_and_5000_and_6mil <- KLpropdata[
KLpropdata$Size_Value >= 3500 & KLpropdata$Size_Value <= 5000 & KLpropdata$Price >= 6000000,]
print(in_between_3500_and_5000_and_6mil)
nrow(in_between_3500_and_5000_and_6mil)
#Output=105

#more_than_5000_and_>=6mil:
more_than_5000_and_6mil <- KLpropdata[
KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000,]
print(more_than_5000_and_6mil)
nrow(more_than_5000_and_6mil)
#Output=170


#Graph for Analysis 3:----------------------------------------------------------------------------------------------------------------------

# Install and load ggplot2 package if not already installed
if (!requireNamespace("ggplot2", quietly = TRUE)) {
  install.packages("ggplot2")
}
library(ggplot2)

# Combine counts into a data frame
count_data <- data.frame(
  Category = c("Less than 3500", "3500 to 5000", "More than 5000"),
  Count = c(
    nrow(lesser_than_3500_and_6mil),
    nrow(in_between_3500_and_5000_and_6mil),
    nrow(more_than_5000_and_6mil)
  )
)

# Custom colors for the bars
custom_colors <- c("#66c2a5", "#fc8d62", "#8da0cb")

# Create a clustered bar plot with solid lines for x-axis and y-axis
ggplot(count_data, aes(x = Category, y = Count, fill = Category)) +
  geom_bar(stat = "identity", position = "dodge") +
  geom_text(aes(label = Count), position = position_dodge(width = 0.9), vjust = -0.5) +
  labs(title = "Analysis 3: Number of Properties by Size Category for Price >= 6,000,000",
       x = "Size Category",
       y = "Number of property") +
  scale_fill_manual(values = custom_colors) +  # Set custom colors
  theme_minimal() +
  theme(axis.line = element_line(color = "black", size = 1),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank())




#-----------------------------------------------------------------------------------------------------------------------------------------

# Analysis 4: Property Analysis Based on Size, Price, and Furnishing Status in Bangsar------------------------------------------------------------

#lesser_than_3500_and_>=6mil_fully_furnished:
fully_furnished <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Fully Furnished" , ]
print(fully_furnished)
nrow(fully_furnished)
#Output= 14

#in_between_3500_and_5000_and_>=6mil_partly_furnished:
partly_furnished <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" , ]
print(partly_furnished)
nrow(partly_furnished)
#Output= 149

#more_than_5000_and_>=6mil_unfurnished:
Unfurnished <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Unfurnished" , ]
print(Unfurnished)
nrow(Unfurnished)
#Output= 7

# Graph for Analysis 4:-----------------------------------------------------------------------------------------------------------------------------------------

# Assuming data_counts_total is the data frame with counts
data_counts_total <- data.frame(
  Furnishing = c("Fully Furnished", "Partly Furnished", "Unfurnished"),
  Count = c(14, 149, 7)
)

# Load ggplot2 library
library(ggplot2)

# Define custom colors
custom_colors <- c("#984ea3", "#91bfdb", "#f781bf")

# Create a stacked bar plot with custom colors, solid axes lines, and count labels
ggplot(data_counts_total, aes(x = Furnishing, y = Count, fill = Furnishing)) +
  geom_bar(stat = "identity") +
  geom_text(aes(label = Count), vjust = -0.5, size = 3) +  # Add count labels above the bars
  scale_fill_manual(values = custom_colors) +  # Set custom colors
  labs(title = "Analysis 4: Property Analysis Based on Size, Price, and Furnishing Types",
       x = "Furnishing Status",
       y = "Number of property") +
  theme_minimal() +
  theme(axis.line = element_line(color = "black", size = 1),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank())



#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Analysis 5: Property Analysis Based on Size, Price, Furnishing and Property Type----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


Bungalow_Corner <-  KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "Bungalow (Corner)" , ]
print(Bungalow_Corner)
nrow(Bungalow_Corner)
#Output = 20

Bungalow <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "Bungalow" , ]
print(Bungalow)
nrow(Bungalow)
#Output = 28

Condominium_Corner <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "Condominium (Corner)" , ]
print(Condominium_Corner)
nrow(Condominium_Corner)
#Output = 29

Bungalow_Intermediate <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "Bungalow (Intermediate)" , ]
print(Bungalow_Intermediate)
nrow(Bungalow_Intermediate)
#Output= 35

Condominium <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "Condominium" , ]
print(Condominium)
nrow(Condominium)
#Output = 28

Semi_Detached_House <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "Semi-detached House" , ]
print(Semi_Detached_House)
nrow(Semi_Detached_House)
#Output = 1

TwoStory_Terrace_LinkHouse_Endlot <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "2-sty Terrace/Link House (Endlot)" , ]
print(TwoStory_Terrace_LinkHouse_Endlot)
nrow(TwoStory_Terrace_LinkHouse_Endlot)
#Output = 0

TwoStory_Terrace_LinkHouse_Intermediate <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "2-sty Terrace/Link House (Intermediate)", ]
print(TwoStory_Terrace_LinkHouse_Intermediate)
nrow(TwoStory_Terrace_LinkHouse_Intermediate)
#Output = 0

TwoStory_Terrace_LinkHouse <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "2-sty Terrace/Link House" , ]
print(TwoStory_Terrace_LinkHouse)
nrow(TwoStory_Terrace_LinkHouse)
#Output = 0

ThreeAndAHalfStory_Terrace_LinkHouse_Intermediate <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "3.5-sty Terrace/Link House (Intermediate)" , ]
print(ThreeAndAHalfStory_Terrace_LinkHouse_Intermediate)
nrow(ThreeAndAHalfStory_Terrace_LinkHouse_Intermediate)
#Output = 0

TwoStory_Terrace_LinkHouse_Corner <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "2-sty Terrace/Link House (Corner)" , ]
print(TwoStory_Terrace_LinkHouse_Corner)
nrow(TwoStory_Terrace_LinkHouse_Corner)
#Output = 0

Semi_Detached_House_Intermediate <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "Semi-detached House (Intermediate)" , ]
print(Semi_Detached_House_Intermediate)
nrow(Semi_Detached_House_Intermediate)
#Output = 0

FourStory_Terrace_LinkHouse_Corner <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "4-sty Terrace/Link House (Corner)" , ]
print(FourStory_Terrace_LinkHouse_Corner)
nrow(FourStory_Terrace_LinkHouse_Corner)
#Output = 0

Condominium_Intermediate <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "Condominium (Intermediate)" , ]
print(Condominium_Intermediate)
nrow(Condominium_Intermediate)
#Output = 4

ThreeStory_Terrace_LinkHouse_Intermediate <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "3-sty Terrace/Link House (Intermediate)", ]
print(ThreeStory_Terrace_LinkHouse_Intermediate)
nrow(ThreeStory_Terrace_LinkHouse_Intermediate)
#Output = 0

Townhouse_EndLot <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "Townhouse (EndLot)", ]
print(Townhouse_EndLot)
nrow(Townhouse_EndLot)
#Output = 0

Semi_Detached_House_Triplex <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "Semi-detached House (Triplex)" , ]
print(Semi_Detached_House_Triplex)
nrow(Semi_Detached_House_Triplex)
#Output = 1

Condominium_Duplex <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "Condominium (Duplex)" , ]
print(Condominium_Duplex)
nrow(Condominium_Duplex)
#Output = 1

Bungalow_EndLot <-  KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "Bungalow (EndLot)" , ]
print(Bungalow_EndLot)
nrow(Bungalow_EndLot)
#Output = 1

Serviced_Residence <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "Serviced Residence", ]
print(Serviced_Residence)
nrow(Serviced_Residence)
#Output = 0

TwoAndAHalfStory_Terrace_LinkHouse_EndLot <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "2.5-sty Terrace/Link House (EndLot)" , ]
print(TwoAndAHalfStory_Terrace_LinkHouse_EndLot)
nrow(TwoAndAHalfStory_Terrace_LinkHouse_EndLot)
#Output = 0

Townhouse <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "Townhouse", ]
print(Townhouse)
nrow(Townhouse)
#Output = 0

Condominium_EndLot <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "Condominium (EndLot)" , ]
print(Condominium_EndLot)
nrow(Condominium_EndLot)
#Output = 0

ThreeAndAHalfStory_Terrace_LinkHouse <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "3.5-sty Terrace/Link House" , ]
print(ThreeAndAHalfStory_Terrace_LinkHouse)
nrow(ThreeAndAHalfStory_Terrace_LinkHouse)
#Output = 0

Residential_Land <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "Residential Land", ]
print(Residential_Land)
nrow(Residential_Land)
#Output = 0

Condominium_Triplex <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "Condominium (Triplex)" , ]
print(Condominium_Triplex)
nrow(Condominium_Triplex)
#Output = 1

FourStory_Terrace_LinkHouse <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "4-sty Terrace/Link House" , ]
print(FourStory_Terrace_LinkHouse)
nrow(FourStory_Terrace_LinkHouse)
#Output = 0

Condominium_Penthouse <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "Condominium (Penthouse)" , ]
print(Condominium_Penthouse)
nrow(Condominium_Penthouse)
#Output = 0

ThreeStory_Terrace_LinkHouse_EndLot <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "3-sty Terrace/Link House (EndLot)", ]
print(ThreeStory_Terrace_LinkHouse_EndLot)
nrow(ThreeStory_Terrace_LinkHouse_EndLot)
#Output = 0

OneAndAHalfStory_Terrace_LinkHouse_Corner <- KLpropdata[KLpropdata$Size_Value > 5000 & KLpropdata$Price >= 6000000 & KLpropdata$Furnishing == "Partly Furnished" & KLpropdata$Property.Type == "1.5-sty Terrace/Link House (Corner)", ]
print(OneAndAHalfStory_Terrace_LinkHouse_Corner)
nrow(OneAndAHalfStory_Terrace_LinkHouse_Corner)
#Output = 0




# Graph for Analysis 5:--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# Assuming you have the required libraries installed
library(ggplot2)

# Creating a data frame with the property types and counts
property_types <- c("Bungalow_Corner", "Bungalow", "Condominium_Corner", "Bungalow_Intermediate", "Condominium", 
                    "Semi_Detached_House", "TwoStory_Terrace_LinkHouse_Endlot", "TwoStory_Terrace_LinkHouse_Intermediate", 
                    "TwoStory_Terrace_LinkHouse", "ThreeAndAHalfStory_Terrace_LinkHouse_Intermediate", 
                    "TwoStory_Terrace_LinkHouse_Corner", "Semi_Detached_House_Intermediate", "FourStory_Terrace_LinkHouse_Corner", 
                    "Condominium_Intermediate", "ThreeStory_Terrace_LinkHouse_Intermediate", "Townhouse_EndLot", 
                    "Semi_Detached_House_Triplex", "Condominium_Duplex", "Bungalow_EndLot", "Serviced_Residence", 
                    "TwoAndAHalfStory_Terrace_LinkHouse_EndLot", "Townhouse", "Condominium_EndLot", 
                    "ThreeAndAHalfStory_Terrace_LinkHouse", "Residential_Land", "Condominium_Triplex", 
                    "FourStory_Terrace_LinkHouse", "Condominium_Penthouse", "ThreeStory_Terrace_LinkHouse_EndLot", 
                    "OneAndAHalfStory_Terrace_LinkHouse_Corner")

property_counts <- c(20, 28, 29, 35, 28, 1, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0)

property_data <- data.frame(PropertyType = property_types, Count = property_counts)

# Custom colors
custom_colors <- c("#1f78b4", "#33a02c", "#e31a1c", "#ff7f00", "#6a3d9a", "#a6cee3", "#b2df8a", "#fb9a99", 
                   "#fdbf6f", "#cab2d6", "#ffff99", "#b15928", "#d7191c", "#fdae61", "#fee08b", "#d73027", 
                   "#4575b4", "#313695", "#74add1", "#4575b4", "#91bfdb", "#313695", "#74add1", "#4575b4", 
                   "#91bfdb", "#4575b4", "#4575b4", "#313695", "#313695", "#ff7f00")

# Check if the length of custom_colors matches the length of property_data
if (length(custom_colors) != nrow(property_data)) {
  stop("Length of custom_colors vector does not match the number of rows in property_data.")
}

# Creating a line graph with custom colors and data labels
ggplot(property_data, aes(x = PropertyType, y = Count, label = Count, color = custom_colors)) +
  geom_line(aes(group = 1)) +  # Connect all data points with a line
  geom_point(size = 2) +
  geom_text(vjust = -0.5, hjust = 1, color = "black") +
  scale_color_manual(values = custom_colors) +
  labs(title = "Analysis 5: Property Count by Type",
       x = "Property Type",
       y = "Number Of Property That is Partly Furnished") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # Rotating x-axis labels for better readability


#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

#DA For Size

A = subset(KLpropdata, Size_Value > 5000 , select = c(Location, Size_Value, Price,Furnishing, Property.Type ))
A
nrow(A)


#DA for Size and Price

AB = subset(A, Price >= 6000000 , select = c(Location, Size_Value, Price,Furnishing, Property.Type ))
AB
nrow(AB)


#DA for Size, Price and Furnishing

ABC = subset(AB , Furnishing == "Partly Furnished" , select = c(Location, Size_Value, Price,Furnishing, Property.Type))
ABC
nrow(ABC)

