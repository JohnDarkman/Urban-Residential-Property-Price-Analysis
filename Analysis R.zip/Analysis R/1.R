
#import default cleaned data for whole dataset------
KLpropdatadefault <- read.csv("C:\\Users\\Jevaan\\OneDrive\\Documents\\APU\\Sem3 y2\\Programming for data analysis\\cleaned_data_default.csv", header = TRUE)

#View table
View(KLpropdatadefault)


# Furnishing status of houses for whole dataset-----


fully_furnished <- KLpropdatadefault[KLpropdatadefault$Furnishing == "Fully Furnished", ]
print(fully_furnished[, c('Location', 'Currency', 'Price', 'Property.Type', 'Size_Type', 
                          'Size_Value', 'Size_Unit', 'Furnishing')])
nrow(fully_furnished)
#Ans = 8742

partly_furnished <- KLpropdatadefault[KLpropdatadefault$Furnishing == "Partly Furnished", ]
print(partly_furnished[, c('Location', 'Currency', 'Price', 'Property.Type', 'Size_Type', 
                           'Size_Value', 'Size_Unit', 'Furnishing')])
nrow(partly_furnished)
#ans = 14817

unfurnished <- KLpropdatadefault[KLpropdatadefault$Furnishing == "Unfurnished", ]
print(unfurnished[, c('Location', 'Currency', 'Price', 'Property.Type', 'Size_Type', 
                      'Size_Value', 'Size_Unit', 'Furnishing')])
nrow(unfurnished)
#ans = 2980

#analysis 1 bar graph for furnishing status of whole dataset-----

# Load the ggplot2 library
library(ggplot2)

# Create a data frame for plotting
furnishing_counts <- data.frame(
  Furnishing = c("Fully Furnished", "Partly Furnished", "Unfurnished"),
  Count = c(nrow(fully_furnished), nrow(partly_furnished), nrow(unfurnished))
)

# Custom colors
custom_colors <- c("#66c2a5", "#fc8d62", "#8da0cb")

# Create a bar chart with custom labels, colors, and themes
ggplot(furnishing_counts, aes(x = Furnishing, y = Count, label = Count)) +
  geom_col(fill = custom_colors, width = 0.5) +
  geom_text(position = position_stack(vjust = 0.5), size = 4, color = "black") +
  labs(title = "Analysis 1: Furnishing status in Kuala Lumpur.",
       x = "Furnishing Status",
       y = "Number of Property") +
  theme_minimal() +
  theme(axis.text.x = element_text(color = "black"),
        axis.text.y = element_text(color = "black"),
        axis.title = element_text(color = "black"),
        panel.grid.major = element_line(color = "gray", linetype = "dashed", size = 0.5),
        panel.grid.minor = element_blank(),
        panel.background = element_rect(fill = c("lightyellow", "lightblue")),  # Change background colors here
        plot.background = element_rect(fill = "white"))







#-----------------------------------------------------------------------------------------------------------------------------------------------
#import clean data for bangsar,Kuala Lumpur only-----
KLpropdata <- read.csv("C:\\Users\\Jevaan\\Downloads\\cleaned_dataset_final (1).csv", header = TRUE)

View(KLpropdata)









# Furnishing status of houses in bangsar Kuala Lumpur-----

fully_furnished <- KLpropdata[ KLpropdata$Furnishing == "Fully Furnished" , ]
print(fully_furnished)
nrow(fully_furnished)
#Ans = 51

partly_furnished <- KLpropdata[KLpropdata$Furnishing == "Partly Furnished" , ]
print(partly_furnished)
nrow(partly_furnished)
#Ans = 443

Unfurnished <- KLpropdata[KLpropdata$Furnishing == "Unfurnished" , ]
print(Unfurnished)
nrow(Unfurnished)
#Ans = 27

# Lolipop Graph for analysis 2------
#install.packages("ggplot2")

library(ggplot2)

# Create a data frame with the counts of each furnishing type
furnishing_counts <- data.frame(
  Furnishing = c("Fully Furnished", "Partly Furnished", "Unfurnished"),
  Count = c(nrow(fully_furnished), nrow(partly_furnished), nrow(Unfurnished))
)

# Custom colors
bar_colors <- c("#FF9999", "#66B2FF", "#99FF99")
segment_color <- "black"
background_color <- "lightyellow"

# Create a lollipop chart with colorful dots and count labels
ggplot(furnishing_counts, aes(x = Furnishing, y = Count)) +
  geom_segment(aes(xend = Furnishing, yend = 0), color = segment_color, size = 1.5) +
  geom_point(aes(color = Furnishing), size = 4) +
  geom_text(aes(label = Count), vjust = -0.5) +  # Add count labels
  scale_color_manual(values = bar_colors) +
  labs(title = "Analysis 2: Furnishing Status in Bangsar",
       x = "Furnishing Type",
       y = "Number of Property") +
  theme_minimal() +
  theme(
    plot.background = element_rect(fill = background_color),
    panel.grid.major = element_line(color = "gray", linetype = "dashed", size = 0.5),
    axis.line.x = element_line(color = "black", size = 1),
    axis.line.y = element_line(color = "black", size = 1),
    axis.text.x = element_text(color = "black"),
    axis.text.y = element_text(color = "black"),
    axis.title = element_text(color = "black")
  )





#----------------------------------------------------------------------------------------------------------------------------------------


# Furnishing status more than and equals to 6 million and less than 6 million------

# fully_furnished >= 6mil
fully_furnished_more_than_and_equals_6mil <- KLpropdata[KLpropdata$Furnishing
                                            == "Fully Furnished" & KLpropdata$Price >= 6000000, ]
print(fully_furnished_more_than_and_equals_6mil)
nrow(fully_furnished_more_than_and_equals_6mil)
#Ans = 18

# fully_furnished < 6mil
fully_furnished_less_than_6mil <- KLpropdata[KLpropdata$Furnishing
                                             == "Fully Furnished" & KLpropdata$Price < 6000000, ]
print(fully_furnished_less_than_6mil)
nrow(fully_furnished_less_than_6mil)
#Ans= 33

#partly_furnished >= 6mil
partly_furnished_more_than_and_equals_6mil <- KLpropdata[KLpropdata$Furnishing
                                           == "Partly Furnished" & KLpropdata$Price >= 6000000, ]
print(partly_furnished_more_than_and_equals_6mil)
nrow(partly_furnished_more_than_and_equals_6mil)
#Ans = 245

#partly_furnished < 6mil
partly_furnished_less_than_6mil <- KLpropdata[KLpropdata$Furnishing
                                            == "Partly Furnished" & KLpropdata$Price < 6000000, ]
print(partly_furnished_less_than_6mil)
nrow(partly_furnished_less_than_6mil)
#Ans = 198

#Unfurnished >= 6 mil
Unfurnished_more_than_and_equals_6mil <- KLpropdata[KLpropdata$Furnishing
                                                == "Unfurnished" & KLpropdata$Price >= 6000000, ]
print(Unfurnished_more_than_and_equals_6mil)
nrow(Unfurnished_more_than_and_equals_6mil)
#Ans = 14

#Unfurnished < 6mil
Unfurnished_less_than_6mil <- KLpropdata[KLpropdata$Furnishing
                                                == "Unfurnished" & KLpropdata$Price < 6000000, ]
print(Unfurnished_less_than_6mil)
nrow(Unfurnished_less_than_6mil)
#Ans = 13

# stacked bar chart for analysis 3-------
# Assuming you have a data frame named KLpropdata with columns Furnishing, Price

# Install and load ggplot2 package if not already installed
# install.packages("ggplot2")
library(ggplot2)
# Create a data frame with counts for each category
data <- data.frame(
  Furnishing = rep(c("Fully Furnished", "Partly Furnished", "Unfurnished"), each = 2),
  PriceRange = rep(c("More than/equal to 6 million", "Less than 6 million"), times = 3),
  Count = c(
    nrow(fully_furnished_more_than_and_equals_6mil),
    nrow(fully_furnished_less_than_6mil),
    nrow(partly_furnished_more_than_and_equals_6mil),
    nrow(partly_furnished_less_than_6mil),
    nrow(Unfurnished_more_than_and_equals_6mil),
    nrow(Unfurnished_less_than_6mil)
  )
)
# Convert Furnishing to a factor
data$Furnishing <- factor(data$Furnishing, levels = c("Fully Furnished", "Partly Furnished", "Unfurnished"))
# Custom colors
metal_color <- "#AAA9AD"  # Metal color
outer_color <- "#FF4500"  # Outside color

# Create a stacked bar chart with count labels
ggplot(data, aes(x = Furnishing, y = Count, fill = PriceRange)) +
  geom_col(color = "blue") +  # White border for better separation
  geom_text(aes(label = Count), position = position_stack(vjust = 0.5), color = "black") +
  scale_fill_manual(values = c(metal_color, outer_color)) +
  labs(
    title = "Analysis 3: Comparison of Furnishing Status and Price Range",
    x = "Furnishing Type",
    y = "Number Of Property",
    fill = "Price Range"
  ) +
  theme_minimal() +
  theme(
    panel.background = element_rect(fill = "lightgray"),  # Change background color
    axis.line = element_line(color = "black", size = 1),   # Highlight x-axis and y-axis
    axis.text.x = element_text(color = "black"),
    axis.text.y = element_text(color = "black"),
    axis.title = element_text(color = "black")
  )







#---------------------------------------------------------------------------------------------------------------------------------------------


# Furnishing status,price range  and Size----------------------------------------------------------------------------------------
#i took the highest value in the furnishing status to price relation

# fully_furnished < 6mil and <3500
fully_furnished_less_than_6mil_and_less_than_3500 <- KLpropdata[KLpropdata$Furnishing
                                                      == "Fully Furnished" & KLpropdata$Price < 6000000 & KLpropdata$Size_Value < 3500, ]
print(fully_furnished_less_than_6mil_and_less_than_3500)
nrow(fully_furnished_less_than_6mil_and_less_than_3500)
#Ans =21

# fully_furnished < 6mil and >=3500 and <=5000
fully_furnished_less_than_6mil_and_3500_to_5000 <- KLpropdata[KLpropdata$Furnishing
                    == "Fully Furnished" & KLpropdata$Price < 6000000 & KLpropdata$Size_Value >= 3500 & KLpropdata$Size_Value <= 5000, ]
print(fully_furnished_less_than_6mil_and_3500_to_5000)
nrow(fully_furnished_less_than_6mil_and_3500_to_5000)
#ans= 7

# fully_furnished < 6mil and >5000
fully_furnished_less_than_6mil_and_greater_than_5000 <- KLpropdata[KLpropdata$Furnishing
                                                     == "Fully Furnished" & KLpropdata$Price < 6000000 & KLpropdata$Size_Value > 5000, ]
print(fully_furnished_less_than_6mil_and_greater_than_5000)
nrow(fully_furnished_less_than_6mil_and_greater_than_5000)
#ans= 5


#Analysis 4 Donought Graph for fully_furnished < 6mil and Size <3500,>=3500 and <=5000>5000-------

library(ggplot2)

# Example data
df <- data.frame(
  Furnishing = rep("Fully Furnished", 3),
  Size_Category = c("< 3500", "3500 - 5000", "> 5000"),
  Count = c(21, 7, 5)
)

# Custom colors
custom_colors <- c("#4169E1", "#32CD32", "#FF4500")

# Donut Chart with custom colors, highlighted lines, and colored background
ggplot(df, aes(x = "", y = Count, fill = Size_Category)) +
  geom_bar(stat = "identity", width = 1, color = "white") +
  coord_polar("y", start = 0) +
  geom_text(aes(label = Count), position = position_stack(vjust = 0.5), color = "black") +
  labs(title = "Fully Furnished and < 6million -Size Category",
       x = NULL,
       y = NULL) +
  scale_fill_manual(values = custom_colors) +
  theme_minimal() +
  theme(
    panel.background = element_rect(fill = "#F5F5F5"),  # Colored background
    axis.line = element_line(color = "black", size = 1.5),   # Highlighted lines
    axis.text = element_text(color = "black")
  )





#partally furnished------
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
# partly_furnished >= 6mil and <3500
partly_furnished_more_than_and_equals_6mil_and_less_than_3500 <- KLpropdata[KLpropdata$Furnishing
                                                        == "Partly Furnished" & KLpropdata$Price >= 6000000 & KLpropdata$Size_Value < 3500, ]
print(partly_furnished_more_than_and_equals_6mil_and_less_than_3500)
nrow(partly_furnished_more_than_and_equals_6mil_and_less_than_3500)
#ans=2

# partly_furnished >= 6mil and >=3500 and <=5000
partly_furnished_more_than_and_equals_6mil_and_3500_to_5000 <- KLpropdata[KLpropdata$Furnishing
                       == "Partly Furnished" & KLpropdata$Price >= 6000000 & KLpropdata$Size_Value >= 3500 & KLpropdata$Size_Value <= 5000, ]
print(partly_furnished_more_than_and_equals_6mil_and_3500_to_5000)
nrow(partly_furnished_more_than_and_equals_6mil_and_3500_to_5000)
#ans= 94

# partly_furnished >= 6mil and >5000
partly_furnished_more_than_and_equals_6mil_and_greater_than_5000 <- KLpropdata[KLpropdata$Furnishing
                                                        == "Partly Furnished" & KLpropdata$Price >= 6000000 & KLpropdata$Size_Value > 5000, ]
print(partly_furnished_more_than_and_equals_6mil_and_greater_than_5000)
nrow(partly_furnished_more_than_and_equals_6mil_and_greater_than_5000)
#ans = 149

#Pie chart for partly_furnished >= 6mil and Size <3500,>=3500 and <=5000>5000-------
library(ggplot2)
library(dplyr)

# Example data
df_partly_furnished <- data.frame(
  Size_Category = c("< 3500", "3500 - 5000", "> 5000"),
  Count = c(2, 94, 149)
)

# Darker metal colors
darker_metal_colors <- c("#6A7B8D", "#737373", "#8B4513")

# Background color
background_color <- "#F5F5F5"

# Create a ggplot pie chart with count values outside, darker metal colors, and a suitable background color
ggplot(df_partly_furnished, aes(x = "", y = Count, fill = Size_Category)) +
  geom_bar(stat = "identity", width = 1, color = background_color) +
  coord_polar("y", start = 0) +
  ggtitle("Partly Furnished >= 6million - Size Category") +  # Centered title
  theme_void() +
  theme(legend.position = "bottom", plot.background = element_rect(fill = background_color)) +
  geom_text(aes(label = Count), position = position_stack(vjust = 0.5), color = "white", size = 4) +
  scale_fill_manual(values = darker_metal_colors)




#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


#Unfurnished------
# Unfurnished >= 6mil and <3500
unfurnished_more_than_and_equals_6mil_and_less_than_3500 <- KLpropdata[KLpropdata$Furnishing
                                                        == "Unfurnished" & KLpropdata$Price >= 6000000 & KLpropdata$Size_Value < 3500, ]
print(unfurnished_more_than_and_equals_6mil_and_less_than_3500)
nrow(unfurnished_more_than_and_equals_6mil_and_less_than_3500)
#ans = 0

# Unfurnished >= 6mil and >=3500 and <=5000
unfurnished_more_than_and_equals_6mil_and_3500_to_5000 <- KLpropdata[KLpropdata$Furnishing
                       == "Unfurnished" & KLpropdata$Price >= 6000000 & KLpropdata$Size_Value >= 3500 & KLpropdata$Size_Value <= 5000, ]
print(unfurnished_more_than_and_equals_6mil_and_3500_to_5000)
nrow(unfurnished_more_than_and_equals_6mil_and_3500_to_5000)
#ans = 7

# Unfurnished >= 6mil and >5000
unfurnished_more_than_and_equals_6mil_and_greater_than_5000 <- KLpropdata[KLpropdata$Furnishing
                                                        == "Unfurnished" & KLpropdata$Price >= 6000000 & KLpropdata$Size_Value > 5000, ]
print(unfurnished_more_than_and_equals_6mil_and_greater_than_5000)
nrow(unfurnished_more_than_and_equals_6mil_and_greater_than_5000)
#ans =7

#line chart Graph for Unfurnished >= 6mil and Size <3500,>=3500 and <=5000>5000-------


#TOTAL = 198
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

library(ggplot2)

# Example data
df_unfurnished <- data.frame(
  Size_Category = c("< 3500", "3500 - 5000", "> 5000"),
  Count = c(0, 7, 7)
)

# Colorful line
colorful_line <- c("#FF0000", "#00FF00", "#0000FF")

# Light orange background color
background_color <- "#FFDAB9"  # Light orange color code

# Line Chart with colorful line, bold count values, increased count size, 
#black grid lines, and light orange background
ggplot(df_unfurnished, aes(x = Size_Category, y = Count, group = 1)) +
  geom_line(color = colorful_line, size = 2) +
  geom_point(color = colorful_line, size = 4) +
  geom_text(aes(label = Count), position = position_nudge(y = 0.2), color = "black", 
            fontface = "bold", size = 5) + 
  # Increase size to 5
  labs(title = "Unfurnished >= 6 million - Size Category",
       x = "Size Category",
       y = "Number Of Property") +
  theme_minimal() +
  theme(
    plot.background = element_rect(fill = background_color),
    panel.grid.major = element_line(color = "black"),  # Set grid color to black
    panel.grid.minor = element_blank(),  # Hide minor grid lines
    axis.line = element_line(color = "black", size = 1),
    axis.text.x = element_text(color = "black"),
    axis.text.y = element_text(color = "black"),
    axis.title = element_text(color = "black")
  )





# List of Property Types--------------

# after analysing all the Furnishing status,price and Size i found out that partly furnished has the highest number of data so now i 
# i will be doing property type now

property_types <- c(
  "Bungalow (Corner)", "Bungalow", "Condominium (Corner)", "Bungalow (Intermediate)", 
  "Condominium", "Semi-detached House", "2-sty Terrace/Link House (EndLot)", 
  "2-sty Terrace/Link House (Intermediate)", "2-sty Terrace/Link House", 
  "3.5-sty Terrace/Link House (Intermediate)", "2-sty Terrace/Link House (Corner)", 
  "Semi-detached House (Intermediate)", "4-sty Terrace/Link House (Corner)", 
  "Condominium (Intermediate)", "3-sty Terrace/Link House (Intermediate)", 
  "Townhouse (EndLot)", "Semi-detached House (Triplex)", "Condominium (Duplex)", 
  "Bungalow (EndLot)", "Serviced Residence", "2.5-sty Terrace/Link House (EndLot)", 
  "Townhouse", "Condominium (EndLot)", "Condominium (Intermediate)", 
  "3.5-sty Terrace/Link House", "Residential Land", "Condominium (Triplex)", 
  "4-sty Terrace/Link House", "Condominium (Penthouse)", "3-sty Terrace/Link House (EndLot)", 
  "1.5-sty Terrace/Link House (Corner)"
)

#Remove duplicates if there is any
property_types <- unique(property_types)

count <- 0

for (property_type in property_types) {
  output <- KLpropdata[
    KLpropdata$Location == "Bangsar, Kuala Lumpur" & 
      KLpropdata$Size_Value > 5000 & 
      KLpropdata$Price >= 6000000 & 
      KLpropdata$Property.Type == property_type & 
      KLpropdata$Furnishing == "Partly Furnished", 
  ]
  
  count <- count + nrow(output)
  
  cat(property_type, "\n")
  print(output)
  cat("Number of properties:", nrow(output), "\n\n")
}

cat("Total number of properties:", count, "\n")














#Graph for property types-----

# Assuming you have the required libraries installed
library(ggplot2)

# Creating a data frame with the property types and counts
property_types <- c("Bungalow_Corner", "Bungalow", "Condominium_Corner", "Bungalow_Intermediate", "Condominium", 
                    "Semi_Detached_House", "TwoStory_Terrace_LinkHouse_Endlot", "TwoStory_Terrace_LinkHouse_Intermediate", 
                    "TwoStory_Terrace_LinkHouse", "ThreeAndAHalfStory_Terrace_LinkHouse_Intermediate", 
                    "TwoStory_Terrace_LinkHouse_Corner", "Semi_Detached_House_Intermediate", "FourStory_Terrace_LinkHouse_Corner", 
                    "Condominium_Intermediate", "ThreeStory_Terrace_LinkHouse_Intermediate", "Townhouse_EndLot", 
                    "Semi_Detached_House_Triplex", "Condominium_Duplex", "Bungalow_EndLot", "Serviced_Residence", 
                    "TwoAndAHalfStory_Terrace_LinkHouse_EndLot", "Townhouse", "Condominium_EndLot", 
                    "ThreeAndAHalfStory_Terrace_LinkHouse", "Residential_Land", "Condominium_Triplex", 
                    "FourStory_Terrace_LinkHouse", "Condominium_Penthouse", "ThreeStory_Terrace_LinkHouse_EndLot", 
                    "OneAndAHalfStory_Terrace_LinkHouse_Corner")

property_counts <- c(20, 28, 29, 35, 28, 1, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0)

property_data <- data.frame(PropertyType = property_types, Count = property_counts)

# Custom colors
custom_colors <- c("#1f78b4", "#33a02c", "#e31a1c", "#ff7f00", "#6a3d9a", "#a6cee3", "#b2df8a", "#fb9a99", 
                   "#fdbf6f", "#cab2d6", "#ffff99", "#b15928", "#d7191c", "#fdae61", "#fee08b", "#d73027", 
                   "#4575b4", "#313695", "#74add1", "#4575b4", "#91bfdb", "#313695", "#74add1", "#4575b4", 
                   "#91bfdb", "#4575b4", "#4575b4", "#313695", "#313695", "#ff7f00")

# Check if the length of custom_colors matches the length of property_data
if (length(custom_colors) != nrow(property_data)) {
  stop("Length of custom_colors vector does not match the number of rows in property_data.")
}

# Creating a line graph with custom colors and data labels
ggplot(property_data, aes(x = PropertyType, y = Count, label = Count, color = custom_colors)) +
  geom_line() +
  geom_point(size = 2) +
  geom_text(vjust = -0.5, hjust = 1, color = "black") +
  geom_segment(aes(x = PropertyType, xend = PropertyType, y = 0, yend = Count), color = custom_colors) +  # Add connecting lines
  scale_color_manual(values = custom_colors) +
  labs(title = "Analysis 5: Property Count by Type",
       x = "Property Type",
       y = "Number Of Property That is Partly Furnished") +
  theme_minimal() +
  theme(panel.background = element_rect(fill = "lightyellow"),  # Change background color here
        axis.text.x = element_text(angle = 45, hjust = 1),  # Rotating x-axis labels for better readability
        axis.line = element_line(color = "black", size = 1),  # Highlight x-axis and y-axis
        panel.grid.major = element_line(color = "darkgrey", linetype = "dashed"))  # Set grid lines color to dark grey




